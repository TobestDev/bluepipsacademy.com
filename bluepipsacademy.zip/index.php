<?php
session_start();
require_once 'Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch all categories (courses)
$stmt = $pdo->prepare("SELECT * FROM categories LIMIT 6");
$stmt->execute();
$categories = $stmt->fetchAll();

// Function to generate course link based on login status
function getCourseLink($courseId, $isLoggedIn) {
    if ($isLoggedIn) {
        return "user/mycourse_request.php?id=" . $courseId;
    } else {
        return "signup.php?redirect=" . urlencode("user/mycourse_request.php?id=" . $courseId);
    }
}

// Fetch active advertisements from the database
$stmtAds = $pdo->prepare("SELECT image_url, redirect_url FROM advertisements WHERE is_active = 1");
$stmtAds->execute();
$ads = $stmtAds->fetchAll();
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bluepips Trading Academy - Online Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="style.css" rel="stylesheet">
   <style>
       /* Add this CSS in style.css */
        .course-card .card-img-top {
            /*width: 100%;*/
            height: auto;
            /*padding-top: 100%; */
            object-fit: cover;
            border-radius: 8px; /* Optional: Rounded corners */
        }

   </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand logo" href="#">Bluepips Trading Academy</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <form class="d-flex mx-auto">
                        <input class="form-control me-2" type="search" placeholder="Search for courses" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signup.php">Free Webinars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="trade_result.php">Trade Result</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonies.php">Testimonies</a>
                        </li>
                        <?php if ($isLoggedIn): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="my_learning.php">My Learning</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php">Log in</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="signup.php">Sign up</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    

                </div>
            </div>
        </nav>
    </header>

<main>
    <ul class="mobile">
                <li class="nav-item">
                    <a class="nav-link" href="free_webinars.php">Free Webinars</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="trade_result.php">Trade Result</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="testimonies.php">Testimonies</a>
                </li>
        </ul>
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <h1>Learn on your schedule</h1>
                <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
                <a href="#courses" class="cta-button">Explore Courses</a>
            </div>
        </section>
         
  <section class="ad-slider-section py-4">
    <div class="container">
        <div class="ad-slider">
            <div id="adCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php foreach ($ads as $index => $ad): ?>
                        <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                            <a href="<?php echo htmlspecialchars($ad['redirect_url']); ?>" target="_blank">
                                <img src="<?php echo htmlspecialchars('../admin/' . ltrim($ad['image_url'], '/')); ?>" class="d-block w-100 rounded" alt="Advertisement">
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <!-- Carousel controls -->
                <button class="carousel-control-prev" type="button" data-bs-target="#adCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#adCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
                <div class="carousel-indicators">
                    <?php foreach ($ads as $index => $ad): ?>
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="<?php echo $index; ?>" class="<?php echo $index === 0 ? 'active' : ''; ?>" aria-current="true" aria-label="Slide <?php echo $index + 1; ?>"></button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

        <section id="courses" class="courses container my-5">
            <h2 class="text-center mb-4">Top Courses</h2>
            <div class="row">
                <?php foreach ($categories as $category): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card course-card">
                            <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($category['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars(substr($category['description'], 0, 100)); ?>...</p>
                                <a href="<?php echo getCourseLink($category['id'], $isLoggedIn); ?>" class="btn btn-primary">View Course</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section id="testimonials" class="container my-5">
            <h2 class="text-center mb-4">What Our Students Say</h2>
            <!-- Add your testimonials here -->
        </section>
        
        <!-- Newsletter Section -->
        <section id="newsletter" class="bg-light py-5">
            <div class="container text-center">
                <h2>Stay Updated!</h2>
                <p>Subscribe to our newsletter and get the latest updates on new courses and promotions.</p>
                <form class="d-flex justify-content-center">
                    <input type="email" class="form-control w-50" placeholder="Enter your email">
                    <button type="submit" class="btn btn-primary ms-2">Subscribe</button>
                </form>
            </div>
        </section>
    </main>

    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>
<footer class="bg-dark text-white pt-5 pb-3">
    <div class="container">
        <div class="row">
            <!-- About Us Section -->
            <div class="col-md-4">
                <h5>About Bluepips Trading Academy</h5>
                <p>Bluepips Trading Academy offers expert-led courses that empower individuals with skills for personal and professional growth. Our mission is to make high-quality education accessible to everyone.</p>
            </div>
            
            <!-- Quick Links Section -->
            <div class="col-md-2">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="free_webinars.php" class="text-white">Free Webinars</a></li>
                    <li><a href="trade_result.php" class="text-white">Trade Result</a></li>
                    <li><a href="testimonies.php" class="text-white">Testimonies</a></li>
                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                </ul>
            </div>

            <!-- Account Links Section -->
            <div class="col-md-2">
                <h5>Account</h5>
                <ul class="list-unstyled">
                    <?php if ($isLoggedIn): ?>
                        <li><a href="my_learning.php" class="text-white">My Learning</a></li>
                        <li><a href="logout.php" class="text-white">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="text-white">Log In</a></li>
                        <li><a href="signup.php" class="text-white">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Contact Information Section -->
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>
                    Bluepips Trading Academy, Inc.<br>
                    Email: <a href="mailto:info@fortunateacademy.com" class="text-white">info@fortunateacademy.com</a>
                </p>
            </div>
        </div>

        <hr class="bg-secondary">
        
        <!-- Social Media and Copyright -->
        <div class="row text-center">
            <div class="col">
                <a href="https://www.facebook.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.twitter.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com/company/fortunateacademy" target="_blank" class="text-white"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>

        <div class="row text-center mt-3">
            <div class="col">
                <p class="mb-0">&copy; <?php echo date("Y"); ?> Bluepips Trading Academy, Inc. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

    <!--<footer class="bg-dark text-white text-center py-3">-->
    <!--    <div class="container">-->
    <!--        <p>&copy; 2024 Bluepips Trading Academy, Inc.</p>-->
    <!--    </div>-->
    <!--</footer>-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>
</body>
</html>