<?php
// Check if user is logged in
session_start();
$isLoggedIn = isset($_SESSION['user_id']);
function getCourseLink($courseId, $isLoggedIn) {
    if ($isLoggedIn) {
        return "user/mycourse_request.php?id=" . $courseId;
    } else {
        return "login.php?redirect=" . urlencode("user/mycourse_request.php?id=" . $courseId);
    }
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'Settings/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer library
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $phone = $_POST['phone'];
    // $category_id = $_POST['category_id'];
    $created_at = date('Y-m-d H:i:s');
    $permission_expiry = date('Y-m-d H:i:s', strtotime('+6 months'));
    $verification_token = bin2hex(random_bytes(50)); // Generate a random token

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) {
        echo "<script>alert('Username already exists. Please choose a different one.'); window.location.href = 'signup.php?category_id=" . urlencode($category_id) . "';</script>";
        exit;
    }

    // Insert new user into database
    $stmt = $pdo->prepare("INSERT INTO users (fullname, email, username, password, phone, is_approved, created_at, permission_expiry, verification_token, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
    $stmt->execute([$fullname, $email, $username, $password, $phone, 0, $created_at, $permission_expiry, $verification_token]);
    $user_id = $pdo->lastInsertId();

    // Assign the user to the category
    // $stmt = $pdo->prepare("INSERT INTO user_categories (user_id) VALUES (?)");
    // $stmt->execute([$user_id, $category_id]);

    // Send verification email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'lorem.ipsum.sample.email@gmail.com'; // Replace with your SMTP username
        $mail->Password = 'tetmxtzkfgkwgpsc'; // Replace with your SMTP password
        $mail->SMTPSecure = 'ssl'; // Use 'tls' if using TLS
        $mail->Port = 465; // 587 for TLS, 465 for SSL

        $mail->setFrom('apstfortunate@gmail.com', 'Apostle Fortunate');
        $mail->addAddress($email);
        $mail->addReplyTo('apstfortunate@gmail.com', 'Apostle Fortunate');

        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $verification_link = "http://courses.apostlefortunate.com/user/verify.php?token=" . $verification_token; // Replace with your domain
        $mail->Body = '
            <p>Dear ' . htmlspecialchars($fullname) . ',</p>
            <p>Thank you for signing up. Please click the link below to verify your email address:</p>
            <p><a href="' . $verification_link . '">Verify Email</a></p>
            <p>If you did not sign up, please ignore this email.</p>
        ';

        $mail->send();
        echo "<script>alert('Signup successful! Please check your email to verify your account.'); window.location.href = 'login.php';</script>";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bluepips Trading Academy - Online Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="style.css" rel="stylesheet">
   <style>
       /* Add this CSS in style.css */
        .course-card .card-img-top {
            /*width: 100%;*/
            height: auto;
            /*padding-top: 100%; */
            object-fit: cover;
            border-radius: 8px; /* Optional: Rounded corners */
        }

   </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand logo" href="#">Bluepips Trading Academy</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <form class="d-flex mx-auto">
                        <input class="form-control me-2" type="search" placeholder="Search for courses" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Free Webinars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="trade_result.php">Trade Result</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonies.php">Testimonies</a>
                        </li>
                        <?php if ($isLoggedIn): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="my_learning.php">My Learning</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php">Log in</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="signup.php">Sign up</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    

                </div>
            </div>
        </nav>
    </header>

<main>
    <ul class="mobile">
                <li class="nav-item">
                    <a class="nav-link" href="free_webinars.php">Free Webinars</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="trade_result.php">Trade Result</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="testimonies.php">Testimonies</a>
                </li>
        </ul>
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
               <h1>Join Our Community</h1>
                 <p>Start your learning journey today. Sign up to access thousands of expert-led courses.</p>
            </div>
        </section>
         
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h2>Signup</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="signup.php">
                            <div class="mb-3">
                                <label for="fullname" class="form-label">Full Name:</label>
                                <input type="text" id="fullname" name="fullname" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" id="email" name="email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username:</label>
                                <input type="text" id="username" name="username" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password:</label><br>
                              <div class="d-flex align-items-center">
                                <input type="password" id="password" name="password" class="form-control ms-2" required>
                                <i class="fas fa-eye toggle-password ms-2" onclick="togglePassword()"></i>
                              </div>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number:</label>
                                <input type="text" id="phone" name="phone" class="form-control" required>
                            </div>
                          
                            <button type="submit" name="signup" class="btn btn-primary">Signup</button>
                        </form>
                        <p class="text-center mt-3">Already have an account? <a href="login.php">Login here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
       <!-- Testimonials Section -->
        <section id="testimonials" class="container my-5">
            <h2 class="text-center mb-4">What Our Students Say</h2>
            <!-- Add your testimonials here -->
        </section>
        
        <!-- Newsletter Section -->
        <section id="newsletter" class="bg-light py-5">
            <div class="container text-center">
                <h2>Stay Updated!</h2>
                <p>Subscribe to our newsletter and get the latest updates on new courses and promotions.</p>
                <form class="d-flex justify-content-center">
                    <input type="email" class="form-control w-50" placeholder="Enter your email">
                    <button type="submit" class="btn btn-primary ms-2">Subscribe</button>
                </form>
            </div>
        </section>
    </main>

    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>
<footer class="bg-dark text-white pt-5 pb-3">
    <div class="container">
        <div class="row">
            <!-- About Us Section -->
            <div class="col-md-4">
                <h5>About Bluepips Trading Academy</h5>
                <p>Bluepips Trading Academy offers expert-led courses that empower individuals with skills for personal and professional growth. Our mission is to make high-quality education accessible to everyone.</p>
            </div>
            
            <!-- Quick Links Section -->
            <div class="col-md-2">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="free_webinars.php" class="text-white">Free Webinars</a></li>
                    <li><a href="trade_result.php" class="text-white">Trade Result</a></li>
                    <li><a href="testimonies.php" class="text-white">Testimonies</a></li>
                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                </ul>
            </div>

            <!-- Account Links Section -->
            <div class="col-md-2">
                <h5>Account</h5>
                <ul class="list-unstyled">
                    <?php if ($isLoggedIn): ?>
                        <li><a href="my_learning.php" class="text-white">My Learning</a></li>
                        <li><a href="logout.php" class="text-white">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="text-white">Log In</a></li>
                        <li><a href="signup.php" class="text-white">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Contact Information Section -->
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>
                    Bluepips Trading Academy, Inc.<br>
                    Email: <a href="mailto:info@fortunateacademy.com" class="text-white">info@fortunateacademy.com</a>
                </p>
            </div>
        </div>

        <hr class="bg-secondary">
        
        <!-- Social Media and Copyright -->
        <div class="row text-center">
            <div class="col">
                <a href="https://www.facebook.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.twitter.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com/company/fortunateacademy" target="_blank" class="text-white"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>

        <div class="row text-center mt-3">
            <div class="col">
                <p class="mb-0">&copy; <?php echo date("Y"); ?> Bluepips Trading Academy, Inc. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

    <!--<footer class="bg-dark text-white text-center py-3">-->
    <!--    <div class="container">-->
    <!--        <p>&copy; 2024 Bluepips Trading Academy, Inc.</p>-->
    <!--    </div>-->
    <!--</footer>-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.querySelector('.toggle-password');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
