<?php
session_start();
require_once 'Settings/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Retrieve user information
$stmt = $pdo->prepare("SELECT fullname, email, verification_token FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($user) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'crm.apostlefortunate.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'admin@crm.apostlefortunate.com'; // Replace with your SMTP username
        $mail->Password = 'Moses14571@'; // Replace with your SMTP password
        $mail->SMTPSecure = 'ssl'; // Use 'tls' if using TLS
        $mail->Port = 465; // 587 for TLS, 465 for SSL

        $mail->setFrom('admin@crm.apostlefortunate.com', 'Apostle Fortunate');
        $mail->addAddress($email);
        $mail->addReplyTo('admin@crm.apostlefortunate.com', 'Apostle Fortunate');

        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = "Hello " . htmlspecialchars($user['fullname']) . ",<br><br>Please verify your email by clicking the following link: <a href='https://courses.apostlefortunate.com/user/verify.php?token=" . $user['verification_token'] . "'>Verify Email</a><br><br>Thank you!";
        $mail->AltBody = "Hello " . htmlspecialchars($user['fullname']) . ",\n\nPlease verify your email by clicking the following link: https://courses.apostlefortunate.com/user/verify.php?token=" . $user['verification_token'] . "\n\nThank you!";

        $mail->send();
        echo 'Verification email has been resent.';
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
    }
} else {
    echo 'User not found.';
}
?>
