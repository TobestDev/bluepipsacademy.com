<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch testimonials from the database
$stmt = $pdo->prepare("SELECT * FROM testimonies ORDER BY created_at DESC");
$stmt->execute();
$testimonials = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Testimonials</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand logo" href="#">Fortunate Academy</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="user/index.php">Free Webinars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="user/index.php">Trade Result</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="testimonies.php">Testimonials</a>
                        </li>
                        <?php if ($isLoggedIn): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="user/index.php">My Learning</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php">Log in</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="signup.php">Sign up</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container my-5">
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <h1>Check our Testimonies</h1>
                <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
                <a href="#courses" class="cta-button">Explore Testimonies</a>
            </div>
        </section>
         <section class="ad-slider-section py-4">
        <div class="container">
            <div class="ad-slider">
                <div id="adCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="../admin/category/1000458998.jpg" class="d-block w-100 rounded" alt="Advertisement 1">
                        </div>
                        <div class="carousel-item">
                            <img src="/api/placeholder/1200/400" class="d-block w-100 rounded" alt="Advertisement 2">
                        </div>
                        <div class="carousel-item">
                            <img src="/api/placeholder/1200/400" class="d-block w-100 rounded" alt="Advertisement 3">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#adCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#adCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <h2 class="text-center mb-4">What Our Students Say</h2>
        <div class="row">
    <?php foreach ($testimonials as $testimonial): ?>
        <div class="col-md-4 mb-4" id="courses">
            <div class="card testimonial-card">
                <div class="card-body text-center">
                   <video width="100%" controls>
                        <source src="<?php echo htmlspecialchars('admin/uploads/testimony/'.$testimonial['original_name']);?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <h5 class="card-title"><?php echo htmlspecialchars($testimonial['title']); ?></h5>
               
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

    </main>

   <!-- Testimonials Section -->
        <section id="testimonials" class="container my-5">
            <h2 class="text-center mb-4">What Our Students Say</h2>
            <!-- Add your testimonials here -->
        </section>
        
        <!-- Newsletter Section -->
        <section id="newsletter" class="bg-light py-5">
            <div class="container text-center">
                <h2>Stay Updated!</h2>
                <p>Subscribe to our newsletter and get the latest updates on new courses and promotions.</p>
                <form class="d-flex justify-content-center">
                    <input type="email" class="form-control w-50" placeholder="Enter your email">
                    <button type="submit" class="btn btn-primary ms-2">Subscribe</button>
                </form>
            </div>
        </section>
    </main>

    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>
<footer class="bg-dark text-white pt-5 pb-3">
    <div class="container">
        <div class="row">
            <!-- About Us Section -->
            <div class="col-md-4">
                <h5>About Fortunate Academy</h5>
                <p>Fortunate Academy offers expert-led courses that empower individuals with skills for personal and professional growth. Our mission is to make high-quality education accessible to everyone.</p>
            </div>
            
            <!-- Quick Links Section -->
            <div class="col-md-2">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="free_webinars.php" class="text-white">Free Webinars</a></li>
                    <li><a href="trade_result.php" class="text-white">Trade Result</a></li>
                    <li><a href="testimonies.php" class="text-white">Testimonies</a></li>
                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                </ul>
            </div>

            <!-- Account Links Section -->
            <div class="col-md-2">
                <h5>Account</h5>
                <ul class="list-unstyled">
                    <?php if ($isLoggedIn): ?>
                        <li><a href="my_learning.php" class="text-white">My Learning</a></li>
                        <li><a href="logout.php" class="text-white">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="text-white">Log In</a></li>
                        <li><a href="signup.php" class="text-white">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Contact Information Section -->
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>
                    Fortunate Academy, Inc.<br>
                    Email: <a href="mailto:info@fortunateacademy.com" class="text-white">info@fortunateacademy.com</a>
                </p>
            </div>
        </div>

        <hr class="bg-secondary">
        
        <!-- Social Media and Copyright -->
        <div class="row text-center">
            <div class="col">
                <a href="https://www.facebook.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.twitter.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com/company/fortunateacademy" target="_blank" class="text-white"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>

        <div class="row text-center mt-3">
            <div class="col">
                <p class="mb-0">&copy; <?php echo date("Y"); ?> Fortunate Academy, Inc. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

    <!--<footer class="bg-dark text-white text-center py-3">-->
    <!--    <div class="container">-->
    <!--        <p>&copy; 2024 Fortunate Academy, Inc.</p>-->
    <!--    </div>-->
    <!--</footer>-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>