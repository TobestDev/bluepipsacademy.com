<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
  
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, phone, category_id, created_at, is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

// if (!$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
//     header("Location: ../no_access.php");
    // echo "You do not have permission to access this page or your permission has expired.";
//     exit;
// }

$user_id = $_SESSION['user_id'];

// Fetch user and category details
$stmt = $pdo->prepare("
    SELECT users.*, categories.name AS category_name 
    FROM users 
    JOIN categories ON users.category_id = categories.id 
    WHERE users.id = :id
");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../acesst/css/style.css">
    <style>
        .card {
            margin-bottom: 1rem;
            position: relative;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
        }
        @media screen and (max-width: 700px) {
            .card {
                margin-bottom: 1rem;
                position: relative;
                display: flex;
                flex-direction: column;
                flex-wrap: wrap;
            }
            .card-body {
                flex: 1 1 auto;
                padding: 0.3rem 0.4rem; 
            }
        }
        .card p {
            font-size: 0.9rem;
            font-weight: bold;
            color: #3498db;
        }
        .card-body h3 {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                 <img src="../pip.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy </h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
                <!-- <img src="../acesst/images/avatar.png" alt="User Avatar" class="avatar ms-2"> -->
            </div>
        </header>
        <!--<header class="d-flex justify-content-between align-items-center p-3">-->
        <!--    <div class="logo d-flex align-items-center">-->
        <!--        <img src="../acesst/images/logo.png" alt="Logo" class="me-2">-->
        <!--        <h1>Video App</h1>-->
        <!--    </div>-->
        <!--    <div class="user-info d-flex align-items-center">-->
        <!--        <span id="username"><?php //echo htmlspecialchars($user['fullname']); ?></span>-->
        <!--        <img src="../acesst/images/avatar.png" alt="User Avatar" class="avatar ms-2">-->
        <!--    </div>-->
        <!--</header>-->
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="courses.php"><i class="fas fa-list"></i>Valuable Courses</a></li>
                <li><a href="approved_courses.php"><i class="fas fa-video"></i> My Learning</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="p-4">
            <h2>Your Profile</h2>
            <div class="card">
                <div class="card-body">
                    <h3>Full Name:</h3>
                    <p><?php echo htmlspecialchars($user['fullname']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Email:</h3>
                    <p><?php echo htmlspecialchars($user['email']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Username:</h3>
                    <p><?php echo htmlspecialchars($user['username']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Phone Number:</h3>
                    <p><?php echo htmlspecialchars($user['phone']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Course:</h3>
                    <p><?php echo htmlspecialchars($user['category_name']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Account Created:</h3>
                    <p><?php echo htmlspecialchars($user['created_at']); ?></p>
                </div>
                <div class="card-body">
                    <h3>Permission Expiry:</h3>
                    <p><?php echo htmlspecialchars($user['permission_expiry']); ?></p>
                </div>
            </div>
            <a href="edit_profile.php" class="btn btn-primary mt-3">Edit Profile</a>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
