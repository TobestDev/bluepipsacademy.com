<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all categories (courses)
$stmt = $pdo->prepare("SELECT * FROM categories");
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Courses</title>
      <link rel="stylesheet" href="../acesst/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                <img src="../assets/images/logo.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy</h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                 <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="courses.php"><i class="fas fa-list"></i>Valuable Courses</a></li>
                <li><a href="approved_courses.php"><i class="fas fa-video"></i> My Learning</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="p-4">
    <div class="container">
        <h2>Available Courses</h2>
        <div class="row">
            <?php foreach ($categories as $category): ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" alt="Course Image" class="img-fluid">

                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                            <h6 class="card-text"><?php echo htmlspecialchars(substr($category['description'], 0, 100)); ?>...</h6>
                            <a href="mycourse_request.php?id=<?php echo $category['id']; ?>" class="btn btn-primary">View Course</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
