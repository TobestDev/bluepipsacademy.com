<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch trade results from the database
$stmt = $pdo->prepare("SELECT * FROM trade_results ORDER BY date DESC");
$stmt->execute();
$tradeResults = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Trade Results</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <?php include 'include/header.php'; ?>

    <main class="container my-5">
        <section class="hero">
            <div class="container">
                <h1>Trade Results</h1>
                <p>Explore our latest trading results and see how our strategies perform.</p>
            </div>
        </section>

        <h2 class="text-center mb-4">Recent Trade Results</h2>
        <div class="row">
            <?php foreach ($tradeResults as $result): ?>
                <div class="col-md-4 mb-4">
                    <div class="card trade-result-card">
                        <div class="card-body text-center">
                            <h5 class="card-title"><?php echo htmlspecialchars($result['title']); ?></h5>
                            <p class="card-text">Date: <?php echo htmlspecialchars(date('Y-m-d', strtotime($result['date']))); ?></p>
                            <p class="card-text">Result: <?php echo htmlspecialchars($result['result']); ?></p>
                            <p class="card-text">Profit/Loss: <?php echo htmlspecialchars($result['profit_loss']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

      <?php include 'include/footer.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>
