<?php
session_start();
require_once '../Settings/config.php';

// Fetch all categories (courses)
$stmt = $pdo->prepare("SELECT * FROM categories LIMIT 6");
$stmt->execute();
$categories = $stmt->fetchAll();

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
// $username = $isLoggedIn ? $_SESSION['username'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Online Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
        }
        .hero {
            background-image: url('assets/images/hero-background.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 4rem 0;
            text-align: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #a435f0;
        }
        .cta-button {
            display: inline-block;
            background: #a435f0;
            color: #fff;
            padding: 0.8rem 2rem;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
        }
        .course-card {
            height: 100%;
        }
        .course-card img {
            height: 150px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand logo" href="#">Fortunate Academy</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <form class="d-flex mx-auto">
                        <input class="form-control me-2" type="search" placeholder="Search for courses" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Categories</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Teach</a>
                        </li>
                        <?php if ($isLoggedIn): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="user/index.php">My Learning</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php">Log in</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="signup.php">Sign up</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <h1>Learn on your schedule</h1>
                <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
                <a href="#courses" class="cta-button">Explore Courses</a>
            </div>
        </section>

        <section id="courses" class="courses container my-5">
            <h2 class="text-center mb-4">Top Courses</h2>
            <div class="row">
                <?php foreach ($categories as $category): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card course-card">
                            <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($category['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars(substr($category['description'], 0, 100)); ?>...</p>
                                <a href="tobesttwo.php?id=<?php echo $category['id']; ?>" class="btn btn-primary">View Course</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="bg-dark text-white text-center py-3">
        <div class="container">
            <p>&copy; 2024 Fortunate Academy, Inc.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>