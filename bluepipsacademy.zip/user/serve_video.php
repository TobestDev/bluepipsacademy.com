<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$videoId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch the user's assigned categories
$stmt = $pdo->prepare("
    SELECT c.id
    FROM categories c
    JOIN user_categories uc ON c.id = uc.category_id
    WHERE uc.user_id = :user_id
");
$stmt->execute(['user_id' => $user_id]);
$user_category_ids = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'id');

if (empty($user_category_ids)) {
    http_response_code(403);
    echo 'Access denied.';
    exit;
}

// Fetch video details
$placeholders = implode(',', array_fill(0, count($user_category_ids), '?'));
$stmt = $pdo->prepare("
    SELECT * 
    FROM video 
    WHERE id = :id AND category_id IN ($placeholders)
");
$stmt->execute(array_merge(['id' => $videoId], $user_category_ids));
$video = $stmt->fetch();

if (!$video) {
    http_response_code(404);
    echo 'Video not found.';
    exit;
}

// Serve the video
$videoPath = "video/" . $video['filename'];

if (file_exists($videoPath)) {
    header('Content-Type: video/mp4');
    header('Content-Length: ' . filesize($videoPath));
    readfile($videoPath);
    exit;
} else {
    http_response_code(404);
    echo 'Video file not found.';
}
