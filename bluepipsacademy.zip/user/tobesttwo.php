<?php
session_start();
require_once '../Settings/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if course ID is provided
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$course_id = $_GET['id'];

// Fetch course details
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    header("Location: index.php");
    exit;
}

// Check if the user has already requested this course
$stmt = $pdo->prepare("SELECT * FROM course_requests WHERE user_id = ? AND course_id = ?");
$stmt->execute([$user_id, $course_id]);
$existing_request = $stmt->fetch();

// Handle course request submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_course'])) {
    if (!$existing_request) {
        $stmt = $pdo->prepare("INSERT INTO course_requests (user_id, course_id, status) VALUES (?, ?, 'pending')");
        $stmt->execute([$user_id, $course_id]);
        $request_message = "Your request has been submitted successfully!";
    } else {
        $request_message = "You have already requested this course.";
    }
}

// Fetch user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($course['name']); ?> - Fortunate Academy</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                <img src="../assets/images/logo.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy</h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="courses.php"><i class="fas fa-list"></i> Valuable Courses</a></li>
                <li><a href="approved_courses.php"><i class="fas fa-video"></i> My Learning</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="p-4">
            <div class="container">
                <h2><?php echo htmlspecialchars($course['name']); ?></h2>
                <div class="row">
                    <div class="col-md-8">
                        <img src="../admin/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['name']); ?>" class="img-fluid mb-3">
                        <h3>Course Description</h3>
                        <p><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Course Details</h5>
                                <p class="card-text"><strong>Duration:</strong> <?php echo htmlspecialchars($course['duration']); ?></p>
                                <p class="card-text"><strong>Difficulty:</strong> <?php echo htmlspecialchars($course['difficulty']); ?></p>
                                <?php if (isset($request_message)): ?>
                                    <div class="alert alert-info" role="alert">
                                        <?php echo $request_message; ?>
                                    </div>
                                <?php elseif ($existing_request): ?>
                                    <div class="alert alert-warning" role="alert">
                                        You have already requested this course. Status: <?php echo ucfirst($existing_request['status']); ?>
                                    </div>
                                <?php else: ?>
                                    <form method="POST">
                                        <button type="submit" name="request_course" class="btn btn-primary btn-block">Request Course Access</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>