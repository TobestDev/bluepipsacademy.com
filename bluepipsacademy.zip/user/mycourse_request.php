<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../Settings/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$category_id = $_GET['id'];

// Fetch course details
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id");
$stmt->execute(['id' => $category_id]);
$category = $stmt->fetch();

if (!$category) {
    die("Course not found.");
}

// Check if user has already applied for this course
$stmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = :user_id AND category_id = :category_id");
$stmt->execute(['user_id' => $user_id, 'category_id' => $category_id]);
$enrollment = $stmt->fetch();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$enrollment) {
        // Insert enrollment with 'pending' status
        $stmt = $pdo->prepare("INSERT INTO enrollments (user_id, category_id, status) VALUES (:user_id, :category_id, 'pending')");
        $stmt->execute(['user_id' => $user_id, 'category_id' => $category_id]);
        
        $message = "Your application has been submitted for approval.";

        // Fetch user's email for sending the notification
        $stmt = $pdo->prepare("SELECT email, username FROM users WHERE id = :id");
        $stmt->execute(['id' => $user_id]);
        $user = $stmt->fetch();

        if ($user) {
            $email = $user['email'];
            $username = $user['username'];
            $mail = new PHPMailer(true);
            
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'lorem.ipsum.sample.email@gmail.com';
                $mail->Password = 'tetmxtzkfgkwgpsc';
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;
                
                $mail->setFrom('admin@crm.apostlefortunate.com', 'Fortunate Academy');
                $mail->addAddress($email, $username);
                $mail->addReplyTo('admin@crm.apostlefortunate.com', 'Fortunate Academy');
                
                $mail->isHTML(true);
                $mail->Subject = 'Course Application Pending Approval';
                $mail->Body    = '
                    <div style="padding: 20px; font-family: Arial, sans-serif; color: #333;">
                        <h2 style="color: #28a745;">Hello, ' . htmlspecialchars($username) . '!</h2>
                        <p>Thank you for applying for the <strong>' . htmlspecialchars($category['name']) . '</strong> course at Fortunate Academy. Your application is currently under review, and we will notify you once it is approved.</p>
                        <p>Meanwhile, feel free to explore other courses on our platform.</p>
                        <p>Best regards,</p>
                        <p><strong>Fortunate Academy Team</strong></p>
                    </div>';
                $mail->AltBody = "Hello, $username! Your application for the " . htmlspecialchars($category['name']) . " course is pending approval.";
                
                $mail->send();
                $message .= " An email has been sent to you.";
            } catch (Exception $e) {
                $message = "Application submitted, but email could not be sent.";
            }
        }
    } else {
        $message = "You have already applied for this course.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="stylesheet" href="include/style.css">
 <!--<link rel="stylesheet" href="../acesst/css/style.css">-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
     
</head>
<body>
     <?php include 'include/header.php'; ?>
    <div class="dashboard">
        <main class="container my-5">
            <div class="row">
                <div class="col-md-8">
                    <h2 class="display-5"><?php echo htmlspecialchars($category['name']); ?></h2>
                    <p class="lead">Category: <span class="fw-bold"><?php echo htmlspecialchars($category['name']); ?></span></p>
                    <p class="lead">Amount: <span class="fw-bold">$<?php echo htmlspecialchars($category['amount']); ?></span></p>
                    <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" alt="Course Image" class="img-fluid mb-4">
                    <h3>Course Details</h3>
                    <p><?php echo htmlspecialchars($category['description']); ?></p>
                    <h4>Course Outline</h4>
                    <ul class="list-unstyled">
                        <!-- Insert course outline items dynamically -->
                        <li>Module 1: Introduction to Course</li>
                        <li>Module 2: Course Overview</li>
                        <li>Module 3: Detailed Learning</li>
                        <li>Module 4: Assessments</li>
                    </ul>
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-info"><?php echo $message; ?></div>
                    <?php endif; ?>
                    <?php if (!$enrollment): ?>
                        <form method="POST">
                            <button type="submit" class="btn btn-primary">Apply for this Course</button>
                        </form>
                    <?php elseif ($enrollment['status'] === 'pending'): ?>
                        <p class="alert alert-warning">Your application is pending approval.</p>
                    <?php elseif ($enrollment['status'] === 'active'): ?>
                        <p class="alert alert-success">You are already enrolled in this course.</p>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <!--<h3>Testimonials</h3>-->
                    <!--<p>What our students say:</p>-->
                    <!-- Insert testimonials here -->
                           <div class="container">
    <h3 class="text-center">Testimonials</h3>
    <p class="text-center mb-4">What our students say:</p>

    <div class="row">
        <!-- Testimonial Card 1 -->
        <div class="col-12 mb-4">
            <div class="card p-3 shadow">
                <div class="card-body">
                    <h5 class="card-title">Tobest Tobest</h5>
                    <p class="card-text">"The course was fantastic! The materials were thorough, and the instructor was engaging and very helpful. Highly recommended!"</p>
                    <div class="rating">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star-half-alt text-warning"></i> <!-- Half star for a 4.5 rating -->
                        <span class="ms-2">4.5/5</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Testimonial Card 2 -->
        <div class="col-12 mb-4">
            <div class="card p-3 shadow">
                <div class="card-body">
                    <h5 class="card-title">Tobest M.</h5>
                    <p class="card-text">"Great course with lots of practical insights. I feel much more prepared now to advance in my career."</p>
                    <div class="rating">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <span class="ms-2">5/5</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Testimonial Card 3 -->
        <div class="col-12 mb-4">
            <div class="card p-3 shadow">
                <div class="card-body">
                    <h5 class="card-title">Alex Lee</h5>
                    <p class="card-text">"This course covered all the essentials and provided hands-on exercises that helped me solidify my learning."</p>
                    <div class="rating">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="far fa-star text-warning"></i> <!-- Outline star for a 4.0 rating -->
                        <span class="ms-2">4/5</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


                </div>
            </div>
        </main>
    </div>

   <?php include 'include/footer.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
