<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch testimonials from the database
$stmt = $pdo->prepare("SELECT * FROM testimonies ORDER BY created_at DESC");
$stmt->execute();
$testimonials = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Testimonials</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
   <?php include 'include/header.php'; ?>

    <main class="container my-5">
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <h1>Check our Testimonies</h1>
                <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
                <a href="#courses" class="cta-button">Explore Testimonies</a>
            </div>
        </section>
         <section class="ad-slider-section py-4">
        <div class="container">
            <div class="ad-slider">
                <div id="adCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="../admin/category/1000458998.jpg" class="d-block w-100 rounded" alt="Advertisement 1">
                        </div>
                        <div class="carousel-item">
                            <img src="/api/placeholder/1200/400" class="d-block w-100 rounded" alt="Advertisement 2">
                        </div>
                        <div class="carousel-item">
                            <img src="/api/placeholder/1200/400" class="d-block w-100 rounded" alt="Advertisement 3">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#adCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#adCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#adCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <h2 class="text-center mb-4">What Our Students Say</h2>
        <div class="row">
    <?php foreach ($testimonials as $testimonial): ?>
        <div class="col-md-4 mb-4" id="courses">
            <div class="card testimonial-card">
                <div class="card-body text-center">
                   <video width="100%" controls>
                        <source src="<?php echo htmlspecialchars('../admin/uploads/testimony/'.$testimonial['original_name']);?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <h5 class="card-title"><?php echo htmlspecialchars($testimonial['title']); ?></h5>
               
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

    </main>

   <?php include 'include/footer.php'; ?>