<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../Settings/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer library
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $phone = $_POST['phone'];
    // $category_id = $_POST['category_id'];
    $created_at = date('Y-m-d H:i:s');
    $permission_expiry = date('Y-m-d H:i:s', strtotime('+6 months'));
    $verification_token = bin2hex(random_bytes(50)); // Generate a random token

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) {
        echo "<script>alert('Username already exists. Please choose a different one.'); window.location.href = 'signup.php?category_id=" . urlencode($category_id) . "';</script>";
        exit;
    }

    // Insert new user into database
    $stmt = $pdo->prepare("INSERT INTO users (fullname, email, username, password, phone, is_approved, created_at, permission_expiry, verification_token, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
    $stmt->execute([$fullname, $email, $username, $password, $phone, 0, $created_at, $permission_expiry, $verification_token]);
    $user_id = $pdo->lastInsertId();

    // Assign the user to the category
    // $stmt = $pdo->prepare("INSERT INTO user_categories (user_id) VALUES (?)");
    // $stmt->execute([$user_id, $category_id]);

    // Send verification email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'lorem.ipsum.sample.email@gmail.com'; // Replace with your SMTP username
        $mail->Password = 'tetmxtzkfgkwgpsc'; // Replace with your SMTP password
        $mail->SMTPSecure = 'ssl'; // Use 'tls' if using TLS
        $mail->Port = 465; // 587 for TLS, 465 for SSL

        $mail->setFrom('apstfortunate@gmail.com', 'Apostle Fortunate');
        $mail->addAddress($email);
        $mail->addReplyTo('apstfortunate@gmail.com', 'Apostle Fortunate');

        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $verification_link = "http://courses.apostlefortunate.com/user/verify.php?token=" . $verification_token; // Replace with your domain
        $mail->Body = '
            <p>Dear ' . htmlspecialchars($fullname) . ',</p>
            <p>Thank you for signing up. Please click the link below to verify your email address:</p>
            <p><a href="' . $verification_link . '">Verify Email</a></p>
            <p>If you did not sign up, please ignore this email.</p>
        ';

        $mail->send();
        echo "<script>alert('Signup successful! Please check your email to verify your account.'); window.location.href = '../index.php';</script>";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    exit;
}

// Get the category_id from the URL
// $category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;
// if (!$category_id) {
//     echo "Category ID is required.";
//     exit;
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h2>Signup</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="signup.php">
                            <div class="mb-3">
                                <label for="fullname" class="form-label">Full Name:</label>
                                <input type="text" id="fullname" name="fullname" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" id="email" name="email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username:</label>
                                <input type="text" id="username" name="username" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password:</label>
                                <input type="password" id="password" name="password" class="form-control" required>
                                <i class="fas fa-eye toggle-password" onclick="togglePassword()"></i>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number:</label>
                                <input type="text" id="phone" name="phone" class="form-control" required>
                            </div>
                            <!--<input type="hidden" name="category_id" value="-->
                            <?
                            // php echo htmlspecialchars($category_id); 
                            ?>">
                            <button type="submit" name="signup" class="btn btn-primary">Signup</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.querySelector('.toggle-password');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
