<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch approved courses for the user
$stmt = $pdo->prepare("
    SELECT e.id AS enrollment_id, c.id AS category_id, c.name AS category_name, e.status, e.created_at 
    FROM enrollments e 
    JOIN categories c ON e.category_id = c.id 
    WHERE e.user_id = :user_id AND e.status = 'active' 
    ORDER BY e.created_at DESC
");
$stmt->execute(['user_id' => $user_id]);
$approved_courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Learning</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="include/style.css">
</head>
<body>
    <?php include 'include/header.php'; ?>
    
    <div class="container my-5">
        <h2 class="text-center mb-4">My Learning</h2>
        
        <?php if (count($approved_courses) > 0): ?>
            <div class="row">
                <?php foreach ($approved_courses as $course): ?>
                    <?php 
                        // Calculate the expiring day (3 months from enrollment)
                        $enrollment_date = strtotime($course['created_at']);
                        $expiration_date = date('Y-m-d', strtotime('+3 months', $enrollment_date));
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="course_details.php?category_id=<?php echo $course['category_id']; ?>" class="text-decoration-none">
                                        <?php echo htmlspecialchars($course['category_name']); ?>
                                    </a>
                                </h5>
                                <p class="card-text">
                                    <strong>Expiring on:</strong> <?php echo date('F j, Y', strtotime($expiration_date)); ?><br>
                                    <strong>Status:</strong> <span class="badge bg-success"><?php echo htmlspecialchars($course['status']); ?></span><br>
                                    <strong>Enrolled on:</strong> <?php echo date('F j, Y', strtotime($course['created_at'])); ?>
                                </p>
                            </div>
                            <div class="card-footer">
                                <a href="course_details.php?category_id=<?php echo $course['category_id']; ?>" class="btn btn-primary w-100">
                                    View Course
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-warning text-center">You have no approved courses.</div>
        <?php endif; ?>
    </div>

    </main>

   <?php include 'include/footer.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
