<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
  
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, phone, category_id, created_at, is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
    header("Location: ../no_access.php");
    // echo "You do not have permission to access this page or your permission has expired.";
    exit;
}

// Calculate total viewers
$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE category_id = :category_id");
$stmt->execute(['category_id' => $user['category_id']]);
$total_users_in_category = $stmt->fetchColumn();
$total_viewers = $total_users_in_category + 1000;

// Calculate total videos in category
$stmt = $pdo->prepare("SELECT COUNT(*) FROM videos WHERE category_id = :category_id");
$stmt->execute(['category_id' => $user['category_id']]);
$total_videos = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../acesst/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                 <img src="../pip.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy </h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
                <!-- <img src="../acesst/images/avatar.png" alt="User Avatar" class="avatar ms-2"> -->
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="video.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="p-4">
            <h2>Welcome to Your Dashboard</h2>
            <p>Your permission is valid until: <?php echo $user['permission_expiry']; ?></p>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3>Total Viewers</h3>
                            <p><?php echo $total_viewers; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3>Total Videos</h3>
                            <p><?php echo $total_videos; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3>Signup Date</h3>
                            <p><?php echo date('F j, Y', strtotime($user['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-4">
                <h3>User Details</h3>
                <ul>
                    <li>Full Name: <?php echo htmlspecialchars($user['username']); ?></li>
                    <li>Email: <?php echo htmlspecialchars($user['email']); ?></li>
                    <li>Phone: <?php echo htmlspecialchars($user['phone']); ?></li>
                    <li>Category ID: <?php echo htmlspecialchars($user['category_id']); ?></li>
                </ul>
            </div>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
