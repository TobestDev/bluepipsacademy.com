<?php
require_once '../Settings/config.php';

$current_time = date("Y-m-d H:i:s");
$stmt = $pdo->prepare("SELECT * FROM webinars WHERE start_time <= ? AND is_active = 1 ORDER BY start_time DESC LIMIT 1");
$stmt->execute([$current_time]);
$webinar = $stmt->fetch();

if ($webinar) {
    echo '<h2>' . htmlspecialchars($webinar['title']) . '</h2>';
    echo '<p>' . htmlspecialchars($webinar['description']) . '</p>';
    echo '<video controls autoplay style="width: 100%;">';
    echo '<source src="' . htmlspecialchars($webinar['video_url']) . '" type="video/mp4">';
    echo 'Your browser does not support the video tag.';
    echo '</video>';
} else {
    echo '<p>No active webinars at the moment.</p>';
}
?>
