<style>
    .testimonial-slider {
        display: flex;
        overflow: hidden;
        position: relative;
        width: 100%;
        max-width: 600px;
        margin: 0 auto;
    }
    .testimonial-slide {
        min-width: 100%;
        box-sizing: border-box;
        padding: 20px;
        text-align: center;
        transition: transform 1s ease-in-out;
    }
    .testimonial-slide p {
        font-style: italic;
        font-size: 1.2em;
        color: #555;
    }
    .testimonial-slide h4 {
        margin-top: 10px;
        color: #333;
    }
    .stars {
        color: #FFD700; /* Gold color for stars */
        font-size: 1.5em;
        margin-top: 5px;
    }
</style>
<!-- Testimonials Section -->
<section id="testimonials" class="container my-5">
    <h2 class="text-center mb-4">What Our Students Say</h2>
    <div class="testimonial-slider">
        <div class="testimonial-slide">
            <p>"The courses have transformed my understanding. I recommend this to every student!"</p>
            <h4>- Chidinma Adeyemi</h4>
            <div class="stars">★★★★★</div>
        </div>
        <div class="testimonial-slide">
            <p>"I have learned so much here! It's a great investment in my future."</p>
            <h4>- Oluwaseun Ayodele</h4>
            <div class="stars">★★★★★</div>
        </div>
        <div class="testimonial-slide">
            <p>"A fantastic learning platform with real-life applications. Highly recommended!"</p>
            <h4>- Blessing Uche</h4>
            <div class="stars">★★★★★</div>
        </div>
        <div class="testimonial-slide">
            <p>"I've gained confidence and skills that will help in my career. Thank you!"</p>
            <h4>- Kehinde Afolabi</h4>
            <div class="stars">★★★★★</div>
        </div>
        <div class="testimonial-slide">
            <p>"Great experience, amazing instructors, and valuable lessons!"</p>
            <h4>- Tunde Okeke</h4>
            <div class="stars">★★★★★</div>
        </div>
    </div>
</section>

       <!-- Newsletter Section -->
        <section id="newsletter" class="bg-light py-5">
            <div class="container text-center">
                <h2>Stay Updated!</h2>
                <p>Subscribe to our newsletter and get the latest updates on new courses and promotions.</p>
                <form class="d-flex justify-content-center">
                    <input type="email" class="form-control w-50" placeholder="Enter your email">
                    <button type="submit" class="btn btn-primary ms-2">Subscribe</button>
                </form>
            </div>
        </section>
    </main>

    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>
<footer class="bg-dark text-white pt-5 pb-3">
    <div class="container">
        <div class="row">
            <!-- About Us Section -->
            <div class="col-md-4">
                <h5>About Bluepips Trading Academy</h5>
                <p>Bluepips Trading Academy offers expert-led courses that empower individuals with skills for personal and professional growth. Our mission is to make high-quality education accessible to everyone.</p>
            </div>
            
            <!-- Quick Links Section -->
            <div class="col-md-2">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="free_webinars.php" class="text-white">Free Webinars</a></li>
                    <li><a href="trade_result.php" class="text-white">Trade Result</a></li>
                    <li><a href="testimonies.php" class="text-white">Testimonies</a></li>
                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                </ul>
            </div>

            <!-- Account Links Section -->
            <div class="col-md-2">
                <h5>Account</h5>
                <ul class="list-unstyled">
                    <?php if ($isLoggedIn): ?>
                        <li><a href="my_learning.php" class="text-white">My Learning</a></li>
                        <li><a href="../logout.php" class="text-white">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="text-white">Log In</a></li>
                        <li><a href="signup.php" class="text-white">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Contact Information Section -->
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>
                    Bluepips Trading Academy, Inc.<br>
                    Email: <a href="mailto:info@fortunateacademy.com" class="text-white">info@fortunateacademy.com</a>
                </p>
            </div>
        </div>

        <hr class="bg-secondary">
        
        <!-- Social Media and Copyright -->
        <div class="row text-center">
            <div class="col">
                <a href="https://www.facebook.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.twitter.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/fortunateacademy" target="_blank" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com/company/fortunateacademy" target="_blank" class="text-white"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>

        <div class="row text-center mt-3">
            <div class="col">
                <p class="mb-0">&copy; <?php echo date("Y"); ?> Bluepips Trading Academy, Inc. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
<script>
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
</script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to feature icons on scroll
        window.addEventListener('scroll', function() {
            const features = document.querySelectorAll('.feature-icon');
            features.forEach(feature => {
                if (isElementInViewport(feature)) {
                    feature.style.animation = 'pulse 1s';
                }
            });
        });

        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }
        // Initialize the carousel with 3-second interval
    document.addEventListener('DOMContentLoaded', function() {
        const adCarousel = new bootstrap.Carousel(document.getElementById('adCarousel'), {
            interval: 3000,  // 3 seconds
            wrap: true,
            pause: 'hover'
        });

        // Optional: Pause on hover
        const carousel = document.querySelector('#adCarousel');
        carousel.addEventListener('mouseenter', () => {
            adCarousel.pause();
        });
        carousel.addEventListener('mouseleave', () => {
            adCarousel.cycle();
        });

        // Preload images for smoother transitions
        const preloadImages = () => {
            const carouselItems = document.querySelectorAll('.carousel-item img');
            carouselItems.forEach(item => {
                const img = new Image();
                img.src = item.src;
            });
        };
        preloadImages();
    });
    </script>
    <!-- JavaScript for continuous sliding functionality -->
<script>
    const testimonialSlider = () => {
    const slides = document.querySelectorAll('.testimonial-slide');
    let currentSlide = 0;

    // Initialize slides
    slides.forEach((slide, index) => {
        if (index !== 0) {
            slide.style.transform = 'translateX(100%)';
        }
    });

    function showNextSlide() {
        // Get the next slide index
        const nextSlide = (currentSlide + 1) % slides.length;

        // Move current slide out to the left
        slides[currentSlide].style.transform = 'translateX(-100%)';
        slides[currentSlide].style.transition = 'transform 1s ease-in-out';

        // Move next slide in from the right
        slides[nextSlide].style.transform = 'translateX(0)';
        slides[nextSlide].style.transition = 'transform 1s ease-in-out';

        // Update current slide
        currentSlide = nextSlide;

        // Reset positions for other slides
        slides.forEach((slide, index) => {
            if (index !== currentSlide) {
                setTimeout(() => {
                    slide.style.transition = 'none';
                    slide.style.transform = 'translateX(100%)';
                    // Re-enable transitions after moving
                    setTimeout(() => {
                        slide.style.transition = 'transform 1s ease-in-out';
                    }, 50);
                }, 1000);
            }
        });
    }

    // Start the slider
    function startSlider() {
        return setInterval(showNextSlide, 4000); // 4 seconds interval
    }

    // Initialize the slider
    let sliderInterval = startSlider();

    // Optional: Pause on hover
    const sliderContainer = document.querySelector('.testimonial-slider');
    
    sliderContainer.addEventListener('mouseenter', () => {
        clearInterval(sliderInterval);
    });

    sliderContainer.addEventListener('mouseleave', () => {
        sliderInterval = startSlider();
    });
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', testimonialSlider);
</script>
</body>
</html>