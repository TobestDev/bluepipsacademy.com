<?php
// session_start();
require_once '../Settings/config.php';

$isLoggedIn = isset($_SESSION['user_id']);
$cartCount = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

// Fetch all categories (courses)
$stmt = $pdo->prepare("SELECT * FROM categories LIMIT 6");
$stmt->execute();
$categories = $stmt->fetchAll();


?>
<style>
/* Hide the mobile list on larger screens */
.mobile {
    display: none;
}

/* Only display on screens smaller than 768px (typical breakpoint for tablets) */
@media (max-width: 767px) {
    .mobile {
        display: flex;
        justify-content: center;
        padding: 0;
        margin-top: 10px;
        list-style-type: none;
    }

    .mobile .nav-item {
        margin: 0 5px; /* Space between buttons */
    }

    .mobile .nav-link {
        display: inline-block;
        padding: 10px 15px;
        background-color: #007bff; /* Button background color */
        color: #ffffff; /* Button text color */
        border-radius: 5px;
        font-weight: bold;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }

    .mobile .nav-link:hover {
        background-color: #0056b3; /* Darker blue on hover */
    }
}

</style>
<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand logo" href="#">Bluepips Trading Academy</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <form class="d-flex mx-auto">
                    <input class="form-control me-2" type="search" placeholder="Search for courses" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
                <ul class="navbar-nav ms-auto">
                     <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="webiner.php">Free webinal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="trade_result.php">Trade Result</a>
                        </li
                        <li class="nav-item">
                            <a class="nav-link" href="testimonies.php">Testimonies</a>
                        </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Teach</a>
                    </li>
                    <?php if ($isLoggedIn): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="approved_courses.php">My Learning</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cart.php">
                                <i class="fas fa-shopping-cart"></i>
                                <!-- Display badge only if cart has items -->
                                <?php if ($cartCount > 0): ?>
                                    <span class="badge bg-danger"><?php echo $cartCount; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Log in</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signup.php">Sign up</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
 <ul class="mobile">
                <li class="nav-item">
                    <a class="nav-link" href="free_webinars.php">Free Webinars</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="trade_result.php">Trade Result</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="testimonies.php">Testimonies</a>
                </li>
        </ul>
