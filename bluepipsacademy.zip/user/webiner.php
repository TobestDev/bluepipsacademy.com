<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);


$current_time = date("Y-m-d H:i:s");
$stmt = $pdo->prepare("SELECT * FROM webinars WHERE start_time <= ? AND is_active = 1 ORDER BY start_time DESC LIMIT 1");
$stmt->execute([$current_time]);
$webinar = $stmt->fetch();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webinar - Fortunate Academy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="include/style.css">
    <style>
          /* Hide controls and disable progress visibility */
        #webinarVideo::-webkit-media-controls { display: none !important; }
        #webinarVideo::-moz-media-controls { display: none !important; }
        #webinarVideo { pointer-events: none; }
        #thankYouMessage {
            display: none;
            font-size: 24px;
            font-weight: bold;
            color: green;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php include 'include/header.php'; ?>
<main>
    <!-- Webinar Video Section -->
    <section class="hero bg-dark text-white">
        <div class="container text-center py-5">
            <h1>Live Webinar</h1>
            <p>Watch the live session and engage with personalized comments.</p>
        </div>
    </section>

   <section class="container my-5">
        <div id="webinarContainer">
            <?php if ($webinar): ?>
                <h2><?php echo htmlspecialchars($webinar['title']); ?></h2>
                <p><?php echo htmlspecialchars($webinar['description']); ?></p>
                <video id="webinarVideo" autoplay muted style="width: 100%;" oncontextmenu="return false;">
                    <source src="<?php echo htmlspecialchars('../admin/' . $webinar['video_url']); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <div id="thankYouMessage">Thank you for watching!</div>

                <!-- Comments Section -->
                <div class="col-lg-4 mt-4">
                    <h4>Comments</h4>
                    <div id="commentsContainer" class="mb-3">
                        <!-- Static comments visible to all -->
                        <div class="comment">
                            <p><strong>Admin:</strong> Welcome to the webinar! Feel free to comment below.</p>
                        </div>
                        <div class="comment">
                            <p><strong>Admin:</strong> Stay tuned for the Q&A session towards the end!</p>
                        </div>
                        <!-- User comments will be appended here -->
                    </div>

                    <!-- User Comment Form -->
                    <form id="userCommentForm" class="mb-3" method="POST">
                        <textarea name="user_comment" id="userComment" class="form-control mb-2" rows="3" placeholder="Write your comment..."></textarea>
                        <button type="button" class="btn btn-primary w-100" onclick="submitComment()">Submit</button>
                    </form>
                </div>
            <?php else: ?>
                <p>No active webinars at the moment.</p>
            <?php endif; ?>
        </div>
    </section>
            </div>

         
</main>

<?php include 'include/footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    // Check for new webinars every minute
    setInterval(function() {
        $.ajax({
            url: 'load_webinar.php',
            type: 'GET',
            success: function(data) {
                $('#webinarContainer').html(data);
            }
        });
    }, 60000);
</script>
<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    });
     document.addEventListener('DOMContentLoaded', function() {
        const video = document.getElementById('webinarVideo');
        const thankYouMessage = document.getElementById('thankYouMessage');

        // Show "Thank you" message and redirect once video ends
        video.addEventListener('ended', function() {
            thankYouMessage.style.display = 'block';
            setTimeout(function() {
                window.location.href = 'index.php';
            }, 3000); // Redirect after 3 seconds
        });
    });
</script>
</body>
</html>
