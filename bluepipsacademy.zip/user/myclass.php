<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

// Fetch all categories
$stmt = $pdo->prepare("SELECT id, name FROM categories ORDER BY name ASC");
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../acesst/css/style.css">
    <style>
        .category-list {
            margin: 20px;
        }
        .category-item {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }
        .category-item a {
            text-decoration: none;
            color: #007BFF;
            font-size: 18px;
            transition: color 0.3s;
        }
        .category-item a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                <img src="../pip.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy</h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="video.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="categories.php"><i class="fas fa-list"></i> Categories</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>

        <main>
            <h2>All Categories</h2>
            <div class="category-list">
                <?php if (count($categories) > 0): ?>
                    <?php foreach ($categories as $category): ?>
                        <div class="category-item">
                            <a href="category_videos.php?category_id=<?php echo htmlspecialchars($category['id']); ?>">
                                <?php echo htmlspecialchars($category['name']); ?>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No categories found.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
