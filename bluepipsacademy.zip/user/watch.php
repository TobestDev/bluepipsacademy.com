<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
    echo "You do not have permission to access this page or your permission has expired.";
    exit;
}

$url = isset($_GET['url']) ? $_GET['url'] : '';

if (!$url) {
    header("Location: video.php");
    exit;
}

$stmt = $pdo->prepare("SELECT title FROM videos WHERE url = :url");
$stmt->execute(['url' => $url]);
$video = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $video['title']; ?></title>
    <link rel="stylesheet" href="../acesst/css/style.css">
</head>
<body>
    <?php include '../Settings/header.php'; ?>
    <div class="container">
        <h1><?php echo $video['title']; ?></h1>
        <video controls width="100%">
            <source src="<?php echo $url; ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <a href="video.php">Back to Video List</a>
    </div>
    <?php include '../Settings/footer.php'; ?>
    <script src="../acesst/js/script.js"></script>
</body>
</html>
