<?php
session_start();
require_once '../Settings/config.php';

// PHPMailer imports
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$category_id = $_GET['id'];

// Fetch course details
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id");
$stmt->execute(['id' => $category_id]);
$category = $stmt->fetch();

if (!$category) {
    die("Course not found.");
}

// Check if user has already applied for this course
$stmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = :user_id AND category_id = :category_id");
$stmt->execute(['user_id' => $user_id, 'category_id' => $category_id]);
$enrollment = $stmt->fetch();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$enrollment) {
        // Insert enrollment with 'pending' status
        $stmt = $pdo->prepare("INSERT INTO enrollments (user_id, category_id, status) VALUES (:user_id, :category_id, 'pending')");
        $stmt->execute(['user_id' => $user_id, 'category_id' => $category_id]);
        
        $message = "Your application has been submitted for approval.";

        // Fetch user's email for sending the notification
        $stmt = $pdo->prepare("SELECT email, username FROM users WHERE id = :id");
        $stmt->execute(['id' => $user_id]);
        $user = $stmt->fetch();

        if ($user) {
            $email = $user['email'];
            $username = $user['username'];
            $mail = new PHPMailer(true);
            
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
                $mail->SMTPAuth = true;
                $mail->Username = 'lorem.ipsum.sample.email@gmail.com'; // Replace with your SMTP username
                $mail->Password = 'tetmxtzkfgkwgpsc'; // Replace with your SMTP password
                $mail->SMTPSecure = 'ssl'; // Use 'tls' for TLS
                $mail->Port = 465; // Port 587 for TLS, 465 for SSL
                
                // Sender and recipient settings
                $mail->setFrom('admin@crm.apostlefortunate.com', 'Fortunate Academy');
                $mail->addAddress($email, $username); // Send to user's email
                $mail->addReplyTo('admin@crm.apostlefortunate.com', 'Fortunate Academy');
                
                // Email subject & body content
                $mail->isHTML(true);
                $mail->Subject = 'Course Application Pending Approval';
                $mail->Body    = '
                    <div style="padding: 20px; font-family: Arial, sans-serif; color: #333;">
                        <h2 style="color: #28a745;">Hello, ' . htmlspecialchars($username) . '!</h2>
                        <p>Thank you for applying for the <strong>' . htmlspecialchars($category['name']) . '</strong> course at Fortunate Academy. Your application is currently under review, and we will notify you once it is approved.</p>
                        <p style="margin-top: 20px;">Meanwhile, feel free to explore other courses on our platform.</p>
                        <p style="margin-top: 40px;">Best regards,</p>
                        <p><strong>Fortunate Academy Team</strong></p>
                    </div>';
                $mail->AltBody = "Hello, $username! Your application for the " . htmlspecialchars($category['name']) . " course is pending approval.";
                
                // Send the email
                $mail->send();
                $message .= " An email has been sent to you.";
            } catch (Exception $e) {
                $message = "Application submitted, but email could not be sent.";
            }
        }
    } else {
        $message = "You have already applied for this course.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="stylesheet" href="../acesst/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                <img src="../assets/images/logo.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy</h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="courses.php"><i class="fas fa-list"></i> Valuable Courses</a></li>
                <li><a href="approved_courses.php"><i class="fas fa-video"></i> My Learning</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="p-4">
            <div class="container">
                <h2><?php echo htmlspecialchars($category['name']); ?></h2>
                
                <!-- Course Image -->
                <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" alt="Course Image" class="img-fluid mb-4">
                
                <!-- Video Preview -->
                <?php if (!empty($category['video_url'])): ?>
                    <div class="video-container mb-4">
                        <video width="100%" controls>
                            <source src="<?php echo htmlspecialchars($category['video_url']); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                <?php endif; ?>
                
                <!-- Course Description -->
                <p><?php echo htmlspecialchars($category['description']); ?></p>

                <?php if (!empty($message)): ?>
                    <div class="alert alert-info alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!$enrollment): ?>
                    <form method="POST">
                        <button type="submit" class="btn btn-success">Apply for this Course</button>
                    </form>
                <?php elseif ($enrollment['status'] === 'pending'): ?>
                    <p class="alert alert-warning">Your application is pending approval.</p>
                    <button class="btn btn-secondary" disabled>Application Pending</button>
                <?php elseif ($enrollment['status'] === 'active'): ?>
                    <p class="alert alert-success">You are enrolled in this course.</p>
                    <button class="btn btn-primary">Start Course</button>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
