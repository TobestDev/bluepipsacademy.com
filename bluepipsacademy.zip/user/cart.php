<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Retrieve courses in the cart
$cart = $_SESSION['cart'] ?? [];
$courseDetails = [];
$totalAmount = 0;

// Fetch details for courses in the cart
if (!empty($cart)) {
    $placeholders = implode(',', array_fill(0, count($cart), '?'));
    $stmt = $pdo->prepare("SELECT id, name, amount, description, image FROM categories WHERE id IN ($placeholders)");
    $stmt->execute($cart);
    $courseDetails = $stmt->fetchAll();

    // Calculate total amount
    foreach ($courseDetails as $course) {
        $totalAmount += $course['amount'];
    }
}

// Function to generate course link based on login status
function getCourseLink($courseId, $isLoggedIn) {
    if ($isLoggedIn) {
        return "mycourse_request.php?id=" . $courseId;
    } else {
        return "../login.php?redirect=" . urlencode("course.php?id=" . $courseId);
    }
}

// Function to add course to cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $courseId = intval($_POST['course_id']);
    if (!in_array($courseId, $_SESSION['cart'])) {
        $_SESSION['cart'][] = $courseId; // Add course to cart
        header("Location: cart.php"); // Redirect to the same page
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://js.paystack.co/v1/inline.js"></script> <!-- Paystack SDK -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    #transferModal .modal-content {
    border-radius: 10px;
}

#countdown {
    font-size: 1.25em;
    color: #e74c3c;
    font-weight: bold;
}

.modal-body h6, .modal-body p {
    margin-bottom: 10px;
}

</style>
</head>
<body>
    <?php include 'include/header.php'; ?>
    <div class="container my-5">
        <h2>My Cart</h2>
        
       <main class="container my-5">
    <h2 class="text-center mb-4">Your Cart</h2>

    <?php if (!empty($courseDetails)): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courseDetails as $course): ?>
                    <tr>
                        <td>
                            <img src="../admin/<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['name']); ?>" style="width: 50px; height: 50px;">
                            <?php echo htmlspecialchars($course['name']); ?>
                        </td>
                        <td><?php echo htmlspecialchars(substr($course['description'], 0, 50)); ?>...</td>
                        <td>$<?php echo number_format($course['amount'], 2); ?></td>
                        <td>
                            <form method="POST" action="">
                                <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($course['id']); ?>">
                                <button type="submit" name="remove_course" class="btn btn-danger">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="2" class="text-end"><strong>Total Amount:</strong></td>
                    <td colspan="2">$<?php echo number_format($totalAmount, 2); ?></td>
                </tr>
            </tbody>
        </table>
        <!--<div class="text-end">-->
        <!--    <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>-->
        <!--</div>-->
    <?php else: ?>
        <p class="text-center">Your cart is empty. <a href="index.php">Continue browsing</a>.</p>
    <?php endif; ?>
</main>
    <!-- Modal for Bank Transfer -->
<div class="modal fade" id="transferModal" tabindex="-1" aria-labelledby="transferModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="transferModalLabel">Bank Transfer & Crypto Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
           <div class="modal-body text-center">
               <p>Total Amount: $<?php echo number_format($course['amount'], 2); ?></p>
                <p>Please transfer the total amount within 2 hours to the account details below:</p>
                <h6>Bank Transfer Details:</h6>
                <hr>
                <p>Bank: KUDA</p>
                <p>Account Number: 2017317825</p>
                <p>Account Name: OBEMBE EMMANUEL</p>
                <hr>
                <h6>Crypto Payment:</h6>
                <p>TRC20 Wallet Address: <strong>TMn5wGUhZDNyA6y2mzfPYRtc1UrkVn4LKp</strong></p>
                <hr>
                <p>BEP20 Wallet Address: <strong>0xd7878c86d8a613de6b0f3ab7c53a774308f8c783</strong></p>
            </div>

                <!-- Countdown Timer -->
                <div id="countdown" class="mt-3 text-danger fs-5 fw-bold" style="text-align:center"></div>

                <!-- WhatsApp Button -->
                <p class="mt-4">After completing the payment, please send the proof to our WhatsApp:</p>
                <a href="https://wa.me/1234567890" class="btn btn-success">Send Proof via WhatsApp</a>
            </div>
        </div>
    </div>
</div>

<!-- Proceed to Checkout Button -->
<div class="text-end">
    <button onclick="openTransferModal()" class="btn btn-primary">Proceed to Checkout</button>
</div>

    <?php include 'include/footer.php'; ?>

    <script>
    function openTransferModal() {
    var transferModal = new bootstrap.Modal(document.getElementById('transferModal'));
    transferModal.show();

    startCountdown(2 * 60 * 60); // Start countdown for 2 hours
}

function startCountdown(duration) {
    var countdownElement = document.getElementById('countdown');
    var timer = duration, hours, minutes, seconds;

    var countdownInterval = setInterval(function () {
        hours = parseInt(timer / 3600, 10);
        minutes = parseInt((timer % 3600) / 60, 10);
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        countdownElement.textContent = hours + ":" + minutes + ":" + seconds;

        if (--timer < 0) {
            clearInterval(countdownInterval);
            countdownElement.textContent = "Time expired! Please contact support.";
        }
    }, 1000);
}

    </script>
</body>
</html>
