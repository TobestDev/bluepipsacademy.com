<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
  
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, phone, category_id, created_at, is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
    header("Location: ../no_access.php");
    // echo "You do not have permission to access this page or your permission has expired.";
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch the user's information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found.";
    exit;
}

// Fetch the user's assigned categories
$stmt = $pdo->prepare("
    SELECT c.id, c.name
    FROM categories c
    JOIN user_categories uc ON c.id = uc.category_id
    WHERE uc.user_id = :user_id
");
$stmt->execute(['user_id' => $user_id]);
$user_categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../acesst/css/style.css">
</head>
<body>
    <div class="dashboard">
       
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                 <img src="../pip.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy </h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
                <!-- <img src="../acesst/images/avatar.png" alt="User Avatar" class="avatar ms-2"> -->
            </div>
        </header>
       
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="video.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main>
            <h2>Settings</h2>
            <form action="update_settings.php" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password">
                    <small>Leave blank if you do not want to change your password</small>
                </div>
                <div class="form-group">
                    <label for="categories">Assigned Categories</label>
                    <ul>
                        <?php foreach ($user_categories as $category): ?>
                            <li><?php echo htmlspecialchars($category['name']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <button type="submit">Save Changes</button>
            </form>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>
