<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
  
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, phone, category_id, created_at, is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

// if (!$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
//     header("Location: ../no_access.php");
//     // echo "You do not have permission to access this page or your permission has expired.";
//     exit;
// }

$user_id = $_SESSION['user_id'];

// Fetch the user's information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found.";
    exit;
}

// Fetch the user's assigned categories
$stmt = $pdo->prepare("
    SELECT c.id, c.name
    FROM categories c
    JOIN user_categories uc ON c.id = uc.category_id
    WHERE uc.user_id = :user_id
");
$stmt->execute(['user_id' => $user_id]);
$user_categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($user_categories)) {
    echo "No categories assigned to the user.";
    exit;
}

// Fetch videos from the user's assigned categories
$category_ids = array_column($user_categories, 'id');
$placeholders = implode(',', array_fill(0, count($category_ids), '?'));

$stmt = $pdo->prepare("
    SELECT v.id, v.title, v.original_name, v.file_path, c.name AS category_name, v.created_at
    FROM videos v
    JOIN categories c ON v.category_id = c.id
    WHERE v.category_id IN ($placeholders)
    ORDER BY v.created_at DESC
");
$stmt->execute($category_ids);
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../acesst/css/style.css">
    <style>
        .video-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .video-card {
            cursor: pointer;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
        }
        .video-thumbnail {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .video-info {
            padding: 10px;
        }
        .video-info h3 {
            margin: 0 0 5px 0;
            font-size: 16px;
        }
        .video-info p {
            margin: 0;
            font-size: 14px;
            color: #666;
        }
         .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 95%;
            overflow: auto;
            background-color: rgba(0,0,0,0.8);
            /*padding-top: 60px;*/
        }

        .modal-content {
            background-color: #fefefe;
            /*margin: 1.5% auto;*/
            padding: 2px;
            border: 1px solid #888;
            width: 100%;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            position: relative;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-video {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .video-controls {
            text-align: center;
            margin-top: -10px;
        }

        .video-controls button {
            background-color: #333;
            color: white;
            border: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .video-controls button:hover {
            background-color: #555;
        }

        .video-controls button i {
            font-size: 16px;
        }

        .video-sidebar {
            margin-top: 20px;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 10px;
        }

        .video-sidebar h3 {
            margin-top: 0;
        }

        .video-sidebar ul {
            list-style: none;
            padding: 0;
        }

        .video-sidebar ul li {
            margin-bottom: 10px;
        }

        .video-sidebar ul li a {
            text-decoration: none;
            color: #007BFF;
            transition: color 0.3s;
        }

        .video-sidebar ul li a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
      <div class="dashboard">
        <header class="d-flex justify-content-between align-items-center p-3">
            <div class="logo d-flex align-items-center">
                 <img src="../pip.png" alt="Logo" class="me-2"> 
                <h1>Fortunate Academy </h1>
            </div>
            <div class="user-info d-flex align-items-center">
                <span id="username"><?php echo htmlspecialchars($user['username']); ?></span>
                <!-- <img src="../acesst/images/avatar.png" alt="User Avatar" class="avatar ms-2"> -->
            </div>
        </header>
        <nav class="sidebar">
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="video.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main>
            <h2>Videos</h2>
            <div class="video-gallery">
                <?php if (count($videos) > 0): ?>
                    <?php foreach ($videos as $video): ?>
                        <div class="video-card" data-id="<?php echo htmlspecialchars($video['id']); ?>" data-title="<?php echo htmlspecialchars($video['title']); ?>" data-url="../uploads/<?php echo htmlspecialchars($video['file_path']); ?>">
                            <!--<img src="../uploads/thumbnails/<?php echo htmlspecialchars($video['id']); ?>.jpg" alt="<?php echo htmlspecialchars($video['title']); ?>" class="video-thumbnail">-->
                            <img src="video.png" class="video-thumbnail">
                            <div class="video-info">
                                <h3><?php echo htmlspecialchars($video['original_name']); ?></h3>
                                <p>Category: <?php echo htmlspecialchars($video['category_name']); ?></p>
                                <!--<p>Uploaded: <?php echo date('M d, Y', strtotime($video['created_at'])); ?></p>-->
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No videos found for your assigned categories.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>

     <div id="videoModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <video id="modalVideo" class="modal-video">
                <source id="modalVideoSource" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="video-controls">
                <button id="playPauseBtn"><i class="fas fa-play"></i></button>
                <button id="stopBtn"><i class="fas fa-stop"></i></button>
                <button id="backwardBtn"><i class="fas fa-backward"></i></button>
                <button id="forwardBtn"><i class="fas fa-forward"></i></button>
                <button id="previousBtn"><i class="fas fa-step-backward"></i></button>
                <button id="nextBtn"><i class="fas fa-step-forward"></i></button>
                <!--<button id="fullscreenBtn"><i class="fas fa-expand"></i></button>-->
            </div>
            <div class="video-sidebar">
                <h3>Other Videos</h3>
                <ul id="videoList">
                    <?php foreach ($videos as $video): ?>
                        <li><a href="#" data-url="../uploads/<?php echo htmlspecialchars($video['file_path']); ?>" data-title="<?php echo htmlspecialchars($video['original_name']); ?>"><?php echo htmlspecialchars($video['original_name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('videoModal');
            const modalVideo = document.getElementById('modalVideo');
            const modalVideoSource = document.getElementById('modalVideoSource');
            const closeBtn = document.getElementsByClassName('close')[0];
            const videoCards = document.querySelectorAll('.video-card');
            const videoLinks = document.querySelectorAll('#videoList a');
            const playPauseBtn = document.getElementById('playPauseBtn');
            const stopBtn = document.getElementById('stopBtn');
            const backwardBtn = document.getElementById('backwardBtn');
            const forwardBtn = document.getElementById('forwardBtn');
            const previousBtn = document.getElementById('previousBtn');
            const nextBtn = document.getElementById('nextBtn');
            const fullscreenBtn = document.getElementById('fullscreenBtn');

            let currentVideoIndex = 0;

            function openModal(url, title) {
                modalVideoSource.src = url;
                modalVideo.load();
                modal.style.display = 'block';
                currentVideoIndex = Array.from(videoLinks).findIndex(link => link.getAttribute('data-url') === url);
            }

            videoCards.forEach(card => {
                card.addEventListener('click', function() {
                    const url = this.getAttribute('data-url');
                    const title = this.getAttribute('data-title');
                    openModal(url, title);
                });
            });

            closeBtn.onclick = function() {
                modal.style.display = 'none';
                modalVideo.pause();
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                    modalVideo.pause();
                }
            }

            videoLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const url = this.getAttribute('data-url');
                    const title = this.getAttribute('data-title');
                    openModal(url, title);
                });
            });

            playPauseBtn.onclick = function() {
                if (modalVideo.paused) {
                    modalVideo.play();
                    playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    modalVideo.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                }
            }

            stopBtn.onclick = function() {
                modalVideo.pause();
                modalVideo.currentTime = 0;
                playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            }

            backwardBtn.onclick = function() {
                modalVideo.currentTime -= 10;
            }

            forwardBtn.onclick = function() {
                modalVideo.currentTime += 10;
            }

            previousBtn.onclick = function() {
                currentVideoIndex = (currentVideoIndex - 1 + videoLinks.length) % videoLinks.length;
                openModal(videoLinks[currentVideoIndex].getAttribute('data-url'), videoLinks[currentVideoIndex].getAttribute('data-title'));
            }

            nextBtn.onclick = function() {
                currentVideoIndex = (currentVideoIndex + 1) % videoLinks.length;
                openModal(videoLinks[currentVideoIndex].getAttribute('data-url'), videoLinks[currentVideoIndex].getAttribute('data-title'));
            }
              fullscreenBtn.onclick = function() {
                if (modalVideo.requestFullscreen) {
                    modalVideo.requestFullscreen();
                } else if (modalVideo.mozRequestFullScreen) {
                    modalVideo.mozRequestFullScreen();
                } else if (modalVideo.webkitRequestFullscreen) {
                    modalVideo.webkitRequestFullscreen();
                } else if (modalVideo.msRequestFullscreen) {
                    modalVideo.msRequestFullscreen();
                }
            }

            modalVideo.addEventListener('enterfullscreen', () => {
                modalVideo.classList.add('fullscreen');
            });
            
             modalVideo.addEventListener('exitfullscreen', () => {
                modalVideo.classList.remove('fullscreen');
            });
            
             function onFullscreenChange() {
                if (document.fullscreenElement) {
                    modalVideo.classList.add('fullscreen');
                } else {
                    modalVideo.classList.remove('fullscreen');
                }
            }
            
              modalVideo.addEventListener('fullscreenchange', () => {
        if (document.fullscreenElement) {
            // Disable download button while in fullscreen
            modalVideo.controls = false;

            // Check if the device is mobile
            if (window.innerWidth < 600) {
                // Forcing landscape mode
                screen.orientation.lock('landscape').catch(err => {
                    console.error(`Error attempting to lock orientation: ${err.message} (${err.name})`);
                });
            }
        } else {
            // Re-enable download button when exiting fullscreen
            modalVideo.controls = false;

            // Unlock orientation
            if (window.innerWidth < 600) {
                screen.orientation.unlock();
            }
        }
    });
            // Disable right-click context menu
            document.addEventListener('contextmenu', function(event) {
                event.preventDefault();
            }, false);

            // Disable screenshot
            document.addEventListener('keyup', function(event) {
                if (event.key === 'PrintScreen') {
                    navigator.clipboard.writeText('');
                    alert("Screenshots are disabled");
                }
            }, false);

            // Disable other keyboard shortcuts
            document.addEventListener('keydown', function(event) {
                if (event.ctrlKey || event.keyCode == 123) {
                    event.stopPropagation();
                    event.preventDefault();
                }
            });
        });
    </script>
</body>
</html>