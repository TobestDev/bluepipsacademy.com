<?php
session_start();
require_once '../Settings/config.php';

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;

// Check if user is enrolled and approved for the selected category
$stmt = $pdo->prepare("
    SELECT e.id AS enrollment_id, c.id AS category_id, c.name AS category_name, e.status 
    FROM enrollments e 
    JOIN categories c ON e.category_id = c.id 
    WHERE e.user_id = :user_id AND c.id = :category_id AND e.status = 'active'
");
$stmt->execute(['user_id' => $user_id, 'category_id' => $category_id]);

// Fetch the result
$enrollment = $stmt->fetch(PDO::FETCH_ASSOC);

// If no enrollment is found or it's not active, deny access
if (!$enrollment) {
    // die("You are not authorized to access this category.");
    header("Location: ../no_access.php");
}

// If enrollment is found, proceed with displaying the video content
// echo "Welcome! You are approved to access videos in the category: " . $enrollment['category_name'];

// Now you can display the video based on the category

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, phone, category_id, is_approved, permission_expiry FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();

// Check if user is approved and permission is still valid
// if (!$user || !$user['is_approved'] || strtotime($user['permission_expiry']) < time()) {
//     header("Location: ../no_access.php");
//     exit;
// }

// Get category ID from the URL
$category_id = $_GET['category_id'] ?? null;
if (!$category_id) {
    echo "Invalid category ID.";
    exit;
}

// Fetch course details based on category ID
$stmt = $pdo->prepare("
    SELECT v.id, v.title, v.original_name, v.file_path, c.name AS category_name, v.created_at
    FROM videos v
    JOIN categories c ON v.category_id = c.id
    WHERE v.category_id = :category_id
    ORDER BY v.created_at DESC
");
$stmt->execute(['category_id' => $category_id]);
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($videos)) {
    echo "No videos found for this category.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Online Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="include/style.css">
    
    <style>
    
        .video-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .video-card {
            cursor: pointer;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
        }
        .video-thumbnail {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .video-info {
            padding: 10px;
        }
        .video-info h3 {
            margin: 0 0 5px 0;
            font-size: 16px;
        }
        .video-info p {
            margin: 0;
            font-size: 14px;
            color: #666;
        }
         .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 95%;
            overflow: auto;
            background-color: rgba(0,0,0,0.8);
            /*padding-top: 60px;*/
        }

        .modal-content {
            background-color: #fefefe;
            /*margin: 1.5% auto;*/
            padding: 2px;
            border: 1px solid #888;
            width: 100%;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            position: relative;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-video {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .video-controls {
            text-align: center;
            margin-top: -10px;
        }

        .video-controls button {
            background-color: #333;
            color: white;
            border: none;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .video-controls button:hover {
            background-color: #555;
        }

        .video-controls button i {
            font-size: 16px;
        }

        .video-sidebar {
            margin-top: 20px;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 10px;
        }

        .video-sidebar h3 {
            margin-top: 0;
        }

        .video-sidebar ul {
            list-style: none;
            padding: 0;
        }

        .video-sidebar ul li {
            margin-bottom: 10px;
        }

        .video-sidebar ul li a {
            text-decoration: none;
            color: #007BFF;
            transition: color 0.3s;
        }

        .video-sidebar ul li a:hover {
            color: #0056b3;
        }
    </style>

</head>
<body>
    <?php include 'include/header.php'; ?>
       <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Learn on your schedule</h1>
            <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
            <a href="#courses" class="cta-button">Explore Courses</a>
        </div>
    </section>
    <div class="dashboard">
        <main>
            <h2>Course Videos for <?php echo htmlspecialchars($videos[0]['category_name']); ?></h2>
            <div class="video-gallery">
                <?php if (count($videos) > 0): ?>
                    <?php foreach ($videos as $video): ?>
                        <div class="video-card" data-id="<?php echo htmlspecialchars($video['id']); ?>" data-title="<?php echo htmlspecialchars($video['title']); ?>" data-url="../uploads/<?php echo htmlspecialchars($video['file_path']); ?>">
                            <!--<img src="../uploads/thumbnails/<?php echo htmlspecialchars($video['id']); ?>.jpg" alt="<?php echo htmlspecialchars($video['title']); ?>" class="video-thumbnail">-->
                            <img src="video.png" class="video-thumbnail">
                            <div class="video-info">
                                <h3><?php echo htmlspecialchars($video['original_name']); ?></h3>
                                <p>Category: <?php echo htmlspecialchars($video['category_name']); ?></p>
                                <!--<p>Uploaded: <?php echo date('M d, Y', strtotime($video['created_at'])); ?></p>-->
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No videos found for your assigned categories.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
 <div id="videoModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <video id="modalVideo" class="modal-video">
                <source id="modalVideoSource" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="video-controls">
                <button id="playPauseBtn"><i class="fas fa-play"></i></button>
                <button id="stopBtn"><i class="fas fa-stop"></i></button>
                <button id="backwardBtn"><i class="fas fa-backward"></i></button>
                <button id="forwardBtn"><i class="fas fa-forward"></i></button>
                <button id="previousBtn"><i class="fas fa-step-backward"></i></button>
                <button id="nextBtn"><i class="fas fa-step-forward"></i></button>
                <!--<button id="fullscreenBtn"><i class="fas fa-expand"></i></button>-->
            </div>
            <div class="video-sidebar">
                <h3>Other Videos</h3>
                <ul id="videoList">
                    <?php foreach ($videos as $video): ?>
                        <li><a href="#" data-url="../uploads/<?php echo htmlspecialchars($video['file_path']); ?>" data-title="<?php echo htmlspecialchars($video['original_name']); ?>"><?php echo htmlspecialchars($video['original_name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
    <?php include 'include/footer.php'; ?>
    <script>
     document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('videoModal');
            const modalVideo = document.getElementById('modalVideo');
            const modalVideoSource = document.getElementById('modalVideoSource');
            const closeBtn = document.getElementsByClassName('close')[0];
            const videoCards = document.querySelectorAll('.video-card');
            const videoLinks = document.querySelectorAll('#videoList a');
            const playPauseBtn = document.getElementById('playPauseBtn');
            const stopBtn = document.getElementById('stopBtn');
            const backwardBtn = document.getElementById('backwardBtn');
            const forwardBtn = document.getElementById('forwardBtn');
            const previousBtn = document.getElementById('previousBtn');
            const nextBtn = document.getElementById('nextBtn');
            const fullscreenBtn = document.getElementById('fullscreenBtn');

            let currentVideoIndex = 0;

            function openModal(url, title) {
                modalVideoSource.src = url;
                modalVideo.load();
                modal.style.display = 'block';
                currentVideoIndex = Array.from(videoLinks).findIndex(link => link.getAttribute('data-url') === url);
            }

            videoCards.forEach(card => {
                card.addEventListener('click', function() {
                    const url = this.getAttribute('data-url');
                    const title = this.getAttribute('data-title');
                    openModal(url, title);
                });
            });

            closeBtn.onclick = function() {
                modal.style.display = 'none';
                modalVideo.pause();
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                    modalVideo.pause();
                }
            }

            videoLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const url = this.getAttribute('data-url');
                    const title = this.getAttribute('data-title');
                    openModal(url, title);
                });
            });

            playPauseBtn.onclick = function() {
                if (modalVideo.paused) {
                    modalVideo.play();
                    playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    modalVideo.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                }
            }

            stopBtn.onclick = function() {
                modalVideo.pause();
                modalVideo.currentTime = 0;
                playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            }

            backwardBtn.onclick = function() {
                modalVideo.currentTime -= 10;
            }

            forwardBtn.onclick = function() {
                modalVideo.currentTime += 10;
            }

            previousBtn.onclick = function() {
                currentVideoIndex = (currentVideoIndex - 1 + videoLinks.length) % videoLinks.length;
                openModal(videoLinks[currentVideoIndex].getAttribute('data-url'), videoLinks[currentVideoIndex].getAttribute('data-title'));
            }

            nextBtn.onclick = function() {
                currentVideoIndex = (currentVideoIndex + 1) % videoLinks.length;
                openModal(videoLinks[currentVideoIndex].getAttribute('data-url'), videoLinks[currentVideoIndex].getAttribute('data-title'));
            }
              fullscreenBtn.onclick = function() {
                if (modalVideo.requestFullscreen) {
                    modalVideo.requestFullscreen();
                } else if (modalVideo.mozRequestFullScreen) {
                    modalVideo.mozRequestFullScreen();
                } else if (modalVideo.webkitRequestFullscreen) {
                    modalVideo.webkitRequestFullscreen();
                } else if (modalVideo.msRequestFullscreen) {
                    modalVideo.msRequestFullscreen();
                }
            }

            modalVideo.addEventListener('enterfullscreen', () => {
                modalVideo.classList.add('fullscreen');
            });
            
             modalVideo.addEventListener('exitfullscreen', () => {
                modalVideo.classList.remove('fullscreen');
            });
            
             function onFullscreenChange() {
                if (document.fullscreenElement) {
                    modalVideo.classList.add('fullscreen');
                } else {
                    modalVideo.classList.remove('fullscreen');
                }
            }
            
              modalVideo.addEventListener('fullscreenchange', () => {
        if (document.fullscreenElement) {
            // Disable download button while in fullscreen
            modalVideo.controls = false;

            // Check if the device is mobile
            if (window.innerWidth < 600) {
                // Forcing landscape mode
                screen.orientation.lock('landscape').catch(err => {
                    console.error(`Error attempting to lock orientation: ${err.message} (${err.name})`);
                });
            }
        } else {
            // Re-enable download button when exiting fullscreen
            modalVideo.controls = false;

            // Unlock orientation
            if (window.innerWidth < 600) {
                screen.orientation.unlock();
            }
        }
    });
            // Disable right-click context menu
            document.addEventListener('contextmenu', function(event) {
                event.preventDefault();
            }, false);

            // Disable screenshot
            document.addEventListener('keyup', function(event) {
                if (event.key === 'PrintScreen') {
                    navigator.clipboard.writeText('');
                    alert("Screenshots are disabled");
                }
            }, false);

            // Disable other keyboard shortcuts
            document.addEventListener('keydown', function(event) {
                if (event.ctrlKey || event.keyCode == 123) {
                    event.stopPropagation();
                    event.preventDefault();
                }
            });
        });
        // document.addEventListener('DOMContentLoaded', function () {
        //     const videoCards = document.querySelectorAll('.video-card');

        //     videoCards.forEach(card => {
        //         card.addEventListener('click', function () {
        //             const videoUrl = this.getAttribute('data-url');
        //             window.open(videoUrl, '_blank'); // Open video in a new tab
        //         });
        //     });
        // });
    </script>
        <script>
                        document.addEventListener('DOMContentLoaded', function() {
                    // Disable right-click context menu
                    document.addEventListener('contextmenu', function(event) {
                        event.preventDefault();
                    }, false);
                
                    // Disable screenshot
                    document.addEventListener('keyup', function(event) {
                        if (event.key === 'PrintScreen') {
                            navigator.clipboard.writeText('');
                            alert("Screenshots are disabled");
                        }
                    }, false);
                
                    // Disable other keyboard shortcuts (Ctrl and F12)
                    document.addEventListener('keydown', function(event) {
                        if (event.ctrlKey || event.keyCode === 123) {
                            event.stopPropagation();
                            event.preventDefault();
                        }
                    });
                });
                
                
                
                document.addEventListener('keydown', function(event) {
                    // Block common shortcuts for dev tools
                    if (event.ctrlKey && (event.shiftKey || event.keyCode === 73 || event.keyCode === 74 || event.keyCode === 67) || event.keyCode === 123) {
                        event.stopPropagation();
                        event.preventDefault();
                    }
                });

    </script>
</body>
</html>
