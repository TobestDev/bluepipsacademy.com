<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../Settings/config.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verify the token
    $stmt = $pdo->prepare("SELECT id FROM users WHERE verification_token = ? AND is_verified = 0");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if ($user) {
        // Mark the user as verified
        $stmt = $pdo->prepare("UPDATE users SET is_verified = 1, verification_token = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);

        echo "<script>alert('Your email has been successfully verified! You can now log in.'); window.location.href = 'https://courses.apostlefortunate.com';</script>";
    } else {
        echo "<script>alert('Invalid or expired token!'); window.location.href = 'https://courses.apostlefortunate.com';</script>";
    }
} else {
    echo "<script>alert('No token provided!'); window.location.href = 'https://courses.apostlefortunate.com/index.php';</script>";
}
?>
