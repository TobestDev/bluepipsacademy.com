<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../Settings/config.php';

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch all categories (courses) including amount
$stmt = $pdo->prepare("SELECT id, name, description, image, amount FROM categories LIMIT 6");
$stmt->execute();
$categories = $stmt->fetchAll();

// Initialize the cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Function to generate course link based on login status
function getCourseLink($courseId, $isLoggedIn) {
    if ($isLoggedIn) {
        return "mycourse_request.php?id=" . $courseId;
    } else {
        return "../login.php?redirect=" . urlencode("course.php?id=" . $courseId);
    }
}

// Function to add course to cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $courseId = intval($_POST['course_id']);
    if (!in_array($courseId, $_SESSION['cart'])) {
        $_SESSION['cart'][] = $courseId; // Add course to cart
        header("Location: cart.php"); // Redirect to the same page
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fortunate Academy - Online Courses</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="include/style.css">
</head>
<body>
<?php include 'include/header.php'; ?>
<main>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Learn on your schedule</h1>
            <p>Study any topic, anytime. Choose from thousands of expert-led courses now.</p>
            <a href="#courses" class="cta-button">Explore Courses</a>
        </div>
    </section>

    <section id="courses" class="courses container my-5">
        <h2 class="text-center mb-4">Top Courses</h2>
        <div class="row">
            <?php foreach ($categories as $category): ?>
                <div class="col-md-4 mb-4">
                    <div class="card course-card">
                        <img src="../admin/<?php echo htmlspecialchars($category['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($category['name']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars(substr($category['description'], 0, 100)); ?>...</p>
                            <p class="card-text"><strong>Amount to be Paid:</strong> $<?php echo number_format($category['amount'], 2); ?></p>

                            <form method="POST" action="">
                                <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($category['id']); ?>">
                                <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                                
                                <a href="<?php echo getCourseLink($category['id'], $isLoggedIn); ?>" class="btn btn-secondary">View Course</a>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php include 'include/footer.php'; ?>
  