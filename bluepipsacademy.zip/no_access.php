<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Access - Your Permission is Expired</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .icon {
            font-size: 60px;
            color: #dc3545;
        }
        h1 {
            color: #dc3545;
        }
        p {
            font-size: 18px;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        footer {
            margin-top: 20px;
            padding: 20px;
            background-color: #e9ecef;
            border-top: 1px solid #dee2e6;
        }
        footer p {
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">
            <i class="bi bi-exclamation-triangle"></i>
        </div>
        <h1>Access Denied</h1>
        <p>You do not have permission to access this page or your permission has expired.</p>
        <p>For assistance, please contact the admin via our WhatsApp group:</p>
        <a href="https://wa.me/your-whatsapp-group-link" class="btn btn-primary" target="_blank">Join WhatsApp Group</a>
    </div>

    <!--<footer>-->
    <!--    <p>If you think this is a mistake, please <a href="logout.php" class="btn btn-primary">Login Again</a></p>-->
    <!--</footer>-->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
