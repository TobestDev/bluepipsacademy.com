<?php
session_start();
require_once '../Settings/config.php'; // Update path as needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    
    if ($action === 'add') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $start_time = $_POST['start_time'];
        $video_url = '';

        if (!empty($_FILES['video']['name'])) {
            $targetDir = "uploads/webinars/";
            $videoName = basename($_FILES['video']['name']);
            $targetFilePath = $targetDir . $videoName;
            $videoFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
            $allowedTypes = ['mp4', 'mov', 'avi', 'flv', 'wmv'];
            $maxFileSize = 50 * 1024 * 1024;

            if (in_array($videoFileType, $allowedTypes) && $_FILES['video']['size'] <= $maxFileSize) {
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0755, true);
                }
                if (move_uploaded_file($_FILES['video']['tmp_name'], $targetFilePath)) {
                    $video_url = $targetFilePath;
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to upload video.']);
                    exit();
                }
            } else {
                $error_message = $_FILES['video']['size'] > $maxFileSize 
                    ? 'File size exceeds the limit of 50MB.' 
                    : 'Invalid file type.';
                echo json_encode(['status' => 'error', 'message' => $error_message]);
                exit();
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No video file uploaded.']);
            exit();
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO webinars (title, description, video_url, start_time) VALUES (?, ?, ?, ?)");
            $stmt->execute([$title, $description, $video_url, $start_time]);
            echo json_encode(['status' => 'success', 'message' => 'Webinar scheduled successfully']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM webinars WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Webinar deleted successfully']);
    } elseif ($action === 'update') {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $start_time = $_POST['start_time'];

        $video_url = $_POST['current_video_url'];
        if (!empty($_FILES['video']['name'])) {
            $targetDir = "uploads/webinars/";
            $videoName = basename($_FILES['video']['name']);
            $targetFilePath = $targetDir . $videoName;
            $videoFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
            $allowedTypes = ['mp4', 'mov', 'avi', 'flv', 'wmv'];
            $maxFileSize = 50 * 1024 * 1024;

            if (in_array($videoFileType, $allowedTypes) && $_FILES['video']['size'] <= $maxFileSize) {
                if (move_uploaded_file($_FILES['video']['tmp_name'], $targetFilePath)) {
                    $video_url = $targetFilePath;
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to upload new video.']);
                    exit();
                }
            } else {
                $error_message = $_FILES['video']['size'] > $maxFileSize 
                    ? 'File size exceeds the limit of 50MB.' 
                    : 'Invalid file type.';
                echo json_encode(['status' => 'error', 'message' => $error_message]);
                exit();
            }
        }

        $stmt = $pdo->prepare("UPDATE webinars SET title = ?, description = ?, video_url = ?, start_time = ? WHERE id = ?");
        $stmt->execute([$title, $description, $video_url, $start_time, $id]);
        echo json_encode(['status' => 'success', 'message' => 'Webinar updated successfully']);
    }
    exit();
}

$webinars = [];
try {
    $stmt = $pdo->query("SELECT * FROM webinars ORDER BY start_time DESC");
    $webinars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching webinars: " . $e->getMessage();
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Testimonies</title>
    <style>
        /* Styles for the progress bar */
        .progress {
            width: 100%;
            background-color: #f3f3f3;
        }
        .progress-bar {
            width: 0;
            height: 20px;
            background-color: #4caf50;
            text-align: center;
            line-height: 20px;
            color: white;
        }
    </style>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
       <?php include 'css/header.php'; ?>
    </div>
    <div class="main-content">
        <h1>Webiner Managenemt</h1>
<!-- HTML Form -->
<form id="webinarForm" enctype="multipart/form-data">
    <input type="hidden" name="id" id="webinarId">
    <input type="text" name="title" id="title" placeholder="Webinar Title" required>
    <textarea name="description" id="description" placeholder="Webinar Description"></textarea>
    <input type="datetime-local" name="start_time" id="start_time" required>
    <input type="file" name="video" id="video" accept="video/*">
    <input type="hidden" name="current_video_url" id="current_video_url">
    <button type="submit">Save Webinar</button>
</form>

<!-- Table to Display Webinars -->
<h2>Scheduled Webinars</h2>
<table border="1">
    <thead>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Start Time</th>
            <th>Video</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($webinars) > 0): ?>
            <?php foreach ($webinars as $webinar): ?>
                <tr>
                    <td><?php echo htmlspecialchars($webinar['title']); ?></td>
                    <td><?php echo htmlspecialchars($webinar['description']); ?></td>
                    <td><?php echo htmlspecialchars($webinar['start_time']); ?></td>
                    <td>
                        <?php if (!empty($webinar['video_url'])): ?>
                            <video width="200" controls>
                                <source src="<?php echo htmlspecialchars($webinar['video_url']); ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        <?php else: ?>
                            No Video
                        <?php endif; ?>
                    </td>
                    <td>
                        <button onclick="editWebinar(<?php echo htmlspecialchars(json_encode($webinar)); ?>)">Update</button>
                        <button onclick="deleteWebinar(<?php echo $webinar['id']; ?>)">Delete</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5">No webinars scheduled.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $('#webinarForm').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        var action = $('#webinarId').val() ? 'update' : 'add';
        formData.append('action', action);
        $.ajax({
            type: 'POST',
            url: 'admin_webinar.php',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                var res = JSON.parse(response);
                alert(res.message);
                if (res.status === 'success') {
                    $('#webinarForm')[0].reset();
                    $('#webinarId').val('');
                    location.reload();
                }
            },
            error: function() {
                alert('An error occurred.');
            }
        });
    });

    function deleteWebinar(id) {
        if (confirm('Are you sure you want to delete this webinar?')) {
            $.ajax({
                type: 'POST',
                url: 'admin_webinar.php',
                data: { action: 'delete', id: id },
                success: function(response) {
                    var res = JSON.parse(response);
                    alert(res.message);
                    if (res.status === 'success') {
                        location.reload();
                    }
                },
                error: function() {
                    alert('An error occurred while deleting the webinar.');
                }
            });
        }
    }

    function editWebinar(webinar) {
        $('#webinarId').val(webinar.id);
        $('#title').val(webinar.title);
        $('#description').val(webinar.description);
        $('#start_time').val(webinar.start_time.replace(' ', 'T'));
        $('#current_video_url').val(webinar.video_url);
    }
</script>
