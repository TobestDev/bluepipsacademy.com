<?php
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Check if a video ID is provided
if (!isset($_GET['id'])) {
    header('Location: videos.php');
    exit();
}

$video_id = intval($_GET['id']);

// Fetch video details
$stmt = $pdo->prepare("SELECT * FROM videos WHERE id = ?");
$stmt->execute([$video_id]);
$video = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$video) {
    echo "<script>alert('Video not found');</script>";
    header('Location: videos.php');
    exit();
}

// Fetch all categories for the form
$stmt = $pdo->prepare("SELECT * FROM categories ORDER BY name ASC");
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $category_id = $_POST['category_id'];
    $new_file = $_FILES['file'];

    // Update the video details in the database
    if ($new_file['error'] === UPLOAD_ERR_OK) {
        $file_name = $new_file['name'];
        $file_tmp = $new_file['tmp_name'];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $new_file_name = uniqid('', true) . '.' . $file_ext;
        $upload_path = '../uploads/' . $new_file_name;

        if (move_uploaded_file($file_tmp, $upload_path)) {
            // Delete the old video file
            $old_file_path = '../uploads/' . $video['file_path'];
            if (file_exists($old_file_path)) {
                unlink($old_file_path);
            }

            // Update the video record with the new file name
            $stmt = $pdo->prepare("UPDATE videos SET title = ?, category_id = ?, original_name = ?, file_path = ? WHERE id = ?");
            $stmt->execute([$title, $category_id, $file_name, $new_file_name, $video_id]);
            echo "<script>alert('Video updated successfully');</script>";
        } else {
            echo "<script>alert('Failed to upload new video file');</script>";
        }
    } else {
        // Update only title and category if no new file is uploaded
        $stmt = $pdo->prepare("UPDATE videos SET title = ?, category_id = ? WHERE id = ?");
        $stmt->execute([$title, $category_id, $video_id]);
        echo "<script>alert('Video updated successfully');</script>";
    }

    // Redirect back to the videos page after update
    header('Location: videos.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Edit Video</title>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="videos.php">Videos</a></li>
                <li><a href="users.php">Users</a></li>
                <li><a href="categories.php">Categories</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <h1>Edit Video</h1>
        
        <form method="POST" enctype="multipart/form-data" class="form">
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" value="<?= htmlspecialchars($video['title']) ?>" required>

            <label for="category_id">Category:</label>
            <select name="category_id" id="category_id" required>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category['id'] ?>" <?= $category['id'] == $video['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="file">Upload New Video (optional):</label>
            <input type="file" name="file" id="file" accept="video/*">
            <p>Current file: <a href="../uploads/<?= htmlspecialchars($video['file_path']) ?>" target="_blank"><?= htmlspecialchars($video['original_name']) ?></a></p>

            <button type="submit">Update Video</button>
        </form>
    </div>
</div>
</body>
</html>
