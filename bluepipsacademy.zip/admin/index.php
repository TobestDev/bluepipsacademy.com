<?php
session_start();
require_once '../Settings/config.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: logout.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT id, password FROM admin WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: dashboard.php");
            exit;
        } else {
            $message = 'Invalid username or password';
        }
    } elseif (isset($_POST['register'])) {
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $stmt = $pdo->prepare("INSERT INTO admin (username, password) VALUES (:username, :password)");
        if ($stmt->execute(['username' => $username, 'password' => $password])) {
            $message = 'Registration successful! You can now log in.';
        } else {
            $message = 'Registration failed. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login/Register</title>
    <!-- <link rel="stylesheet" href="../acesst/css/style.css"> -->
     <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    background-color: #fff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
}

h1 {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.form-container {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

input[type="text"],
input[type="password"] {
    padding: 0.75rem;
    font-size: 1rem;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    padding: 0.75rem;
    font-size: 1rem;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

p {
    color: red;
    margin-top: 0.5rem;
    font-size: 0.9rem;
}

h2 {
    margin-bottom: 0.5rem;
    font-size: 1.5rem;
}
     </style>
</head>
<body>
    <div class="container">
        <h1>Admin Login or Register</h1>
        <p><?php echo $message; ?></p>
        <div class="form-container">
            <form action="index.php" method="POST">
                <h2>Login</h2>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
            </form>
            <!-- <form action="index.php" method="POST">
                <h2>Register</h2>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="register">Register</button>
            </form> -->
        </div>
    </div>
    <script src="../acesst/js/script.js"></script>
</body>
</html>
