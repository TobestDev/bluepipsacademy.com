<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = intval($_GET['id']);
    $newStatus = ($_GET['action'] === 'activate') ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE advertisements SET is_active = ? WHERE id = ?");
    $stmt->execute([$newStatus, $id]);

    header('Location: ads_settings.php');
    exit();
}
