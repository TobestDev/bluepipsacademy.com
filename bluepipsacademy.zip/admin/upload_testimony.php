<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Handle video (now testimony) deletion
if (isset($_GET['delete'])) {
    $testimony_id = intval($_GET['delete']);

    // Fetch the testimony details to delete the file from the server
    $stmt = $pdo->prepare("SELECT file_path FROM testimonies WHERE id = ?");
    $stmt->execute([$testimony_id]);
    $testimony = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($testimony) {
        // Delete the file from the server
        $file_path = '../uploads/testimony/' . $testimony['file_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // Delete the testimony from the database
        $stmt = $pdo->prepare("DELETE FROM testimonies WHERE id = ?");
        $stmt->execute([$testimony_id]);

        if ($stmt->rowCount()) {
            echo "<script>alert('Testimony deleted successfully');</script>";
        } else {
            echo "<script>alert('Failed to delete testimony from database');</script>";
        }
    } else {
        echo "<script>alert('Testimony not found');</script>";
    }

    // Redirect to avoid the delete query being triggered on page reload
    header('Location: testimonies.php');
    exit();
}

// Fetch all testimonies
$stmt = $pdo->prepare("SELECT id, title, original_name, file_path FROM testimonies ORDER BY created_at DESC");
$stmt->execute();
$testimonies = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Testimonies</title>
    <style>
        /* Styles for the progress bar */
        .progress {
            width: 100%;
            background-color: #f3f3f3;
        }
        .progress-bar {
            width: 0;
            height: 20px;
            background-color: #4caf50;
            text-align: center;
            line-height: 20px;
            color: white;
        }
    </style>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
       <?php include 'css/header.php'; ?>
    </div>
    <div class="main-content">
        <h1>Manage Testimonies</h1>
        
        <!-- Add Testimony Form -->
        <form id="upload-form" class="form">
            <h2>Add New Testimony</h2>
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" required>
            <label for="files">Select Videos:</label>
            <input type="file" name="files[]" id="files" multiple accept="video/*" required>
            <button type="button" id="upload-button">Add Testimonies</button>
        </form>

        <!-- Progress Bar -->
        <div class="progress">
            <div class="progress-bar" id="progress-bar">0%</div>
        </div>

        <!-- Testimonies Table -->
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Original Name</th>
                    <th>File Path</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($testimonies as $testimony): ?>
                    <tr>
                        <td><?= htmlspecialchars($testimony['title']) ?></td>
                        <td><?= htmlspecialchars($testimony['original_name']) ?></td>
                        <td><a href="../uploads/testimony/<?= htmlspecialchars($testimony['file_path']) ?>" target="_blank"><?= htmlspecialchars($testimony['file_path']) ?></a></td>
                        <td>
                            <a href="edit_testimony.php?id=<?= $testimony['id'] ?>">Edit</a> | 
                            <a href="testimonies.php?delete=<?= $testimony['id'] ?>" onclick="return confirm('Are you sure you want to delete this testimony?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.getElementById('upload-button').addEventListener('click', function() {
        const form = document.getElementById('upload-form');
        const formData = new FormData(form);
        const files = document.getElementById('files').files;
        const progressBar = document.getElementById('progress-bar');
        const totalFiles = files.length;

        if (totalFiles === 0) {
            alert('Please select files to upload.');
            return;
        }

        let uploadedFiles = 0;

        function uploadNextFile(index) {
            if (index >= totalFiles) {
                progressBar.style.width = '100%';
                progressBar.innerHTML = 'Upload Complete';
                setTimeout(() => location.reload(), 1000);
                return;
            }

            const fileData = new FormData();
            fileData.append('file', files[index]);
            fileData.append('title', formData.get('title'));

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload_testimony.php', true);

            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    progressBar.style.width = percentComplete + '%';
                    progressBar.innerHTML = Math.round(percentComplete) + '%';
                }
            });

            xhr.onload = function() {
                if (xhr.status === 200) {
                    uploadedFiles++;
                    const overallProgress = (uploadedFiles / totalFiles) * 100;
                    progressBar.style.width = overallProgress + '%';
                    progressBar.innerHTML = Math.round(overallProgress) + '%';
                    uploadNextFile(index + 1);
                } else {
                    alert('Error uploading file.');
                }
            };

            xhr.send(fileData);
        }

        uploadNextFile(0);
    });
</script>
</body>
</html>
