<?php
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Fetch the category to edit
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);

    // If category doesn't exist, redirect
    if (!$category) {
        header('Location: categories.php');
        exit();
    }
} else {
    header('Location: categories.php');
    exit();
}

// Handle editing the category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_category'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $course_outline = $_POST['course_outline'] ?? null; // Optional
    $advantages = $_POST['advantages'] ?? null; // Optional
    $certification = $_POST['certification'] ?? null; // Optional

    // Check if a new image is uploaded
    if (!empty($_FILES['image']['name'])) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $upload_dir = 'category/';
        $image_path = $upload_dir . basename($image_name);
        move_uploaded_file($image_tmp, $image_path);

        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, image = ?, course_outline = ?, advantages = ?, certification = ? WHERE id = ?");
        $stmt->execute([$name, $description, $image_path, $course_outline, $advantages, $certification, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, course_outline = ?, advantages = ?, certification = ? WHERE id = ?");
        $stmt->execute([$name, $description, $course_outline, $advantages, $certification, $id]);
    }

    header('Location: categories.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Edit Category</title>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="videos.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="categories.php"><i class="fas fa-tags"></i> Categories</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="admin_approvals.php"><i class="fas fa-cog"></i> Course Approvals</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <h1>Edit Category</h1>
        
        <!-- Edit Category Form -->
        <form method="POST" enctype="multipart/form-data" class="form">
            <input type="hidden" name="id" value="<?= htmlspecialchars($category['id']) ?>">
            <label for="name">Category Name:</label>
            <input type="text" name="name" id="name" value="<?= htmlspecialchars($category['name']) ?>" required>

            <label for="description">Category Description:</label>
            <textarea name="description" id="description" required><?= htmlspecialchars($category['description']) ?></textarea>

            <label for="course_outline">Course Outline:</label>
            <textarea name="course_outline" id="course_outline" placeholder="Optional"><?= htmlspecialchars($category['course_outline']) ?></textarea>

            <label for="advantages">Advantages of the Course:</label>
            <textarea name="advantages" id="advantages" placeholder="Optional"><?= htmlspecialchars($category['advantages']) ?></textarea>

            <label for="certification">Certification:</label>
            <textarea name="certification" id="certification" placeholder="Optional"><?= htmlspecialchars($category['certification']) ?></textarea>

            <label for="image">Category Image:</label>
            <input type="file" name="image" id="image" accept="image/*">

            <label>Current Image:</label>
            <?php if ($category['image']): ?>
                <img src="<?= $category['image'] ?>" alt="<?= htmlspecialchars($category['name']) ?>" style="width: 100px; height: auto;">
            <?php else: ?>
                No Image
            <?php endif; ?>

            <button type="submit" name="edit_category">Update Category</button>
        </form>
    </div>
</div>
</body>
</html>
