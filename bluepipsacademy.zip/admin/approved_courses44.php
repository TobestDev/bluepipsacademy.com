<?php
session_start();
require_once '../Settings/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Check if user is logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: logout.php");
    exit;
}

// Pagination settings
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search and filter
$search = isset($_GET['search']) ? $_GET['search'] : '';
$categoryFilter = isset($_GET['category']) ? $_GET['category'] : '';

// Fetch categories for the filter
$categories = $pdo->query("SELECT id, name FROM categories")->fetchAll();

// Fetch all enrollments with search and filter
$query = "SELECT e.id, e.user_id, e.category_id, e.status, u.username, u.email, c.name AS category_name, e.created_at 
          FROM enrollments e 
          JOIN users u ON e.user_id = u.id 
          JOIN categories c ON e.category_id = c.id 
          WHERE 1=1"; // Fetch all statuses

if ($search) {
    $query .= " AND (u.username LIKE :search OR c.name LIKE :search)";
}

if ($categoryFilter) {
    $query .= " AND e.category_id = :category";
}

$query .= " ORDER BY e.created_at DESC LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);

if ($search) {
    $stmt->bindValue(':search', '%' . $search . '%');
}

if ($categoryFilter) {
    $stmt->bindValue(':category', $categoryFilter, PDO::PARAM_INT);
}

$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$enrollments = $stmt->fetchAll();

// Handle approval, rejection, and revoking access
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enrollment_id = $_POST['enrollment_id'];
    $action = $_POST['action'];
    
    // Fetch the user details
    $userStmt = $pdo->prepare("SELECT u.email, u.username, c.name AS category_name 
                               FROM enrollments e 
                               JOIN users u ON e.user_id = u.id 
                               JOIN categories c ON e.category_id = c.id 
                               WHERE e.id = :id");
    $userStmt->execute(['id' => $enrollment_id]);
    $user = $userStmt->fetch();

    // Initialize PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'lorem.ipsum.sample.email@gmail.com';
        $mail->Password   = 'tetmxtzkfgkwgpsc';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
        $mail->setFrom('apstfortunate@gmail.com', 'Admin');
        $mail->addAddress($user['email']);
        $mail->addReplyTo('apstfortunate@gmail.com', 'Admin');
        
        if ($action === 'approve') {
            // Update the enrollment status
            $stmt = $pdo->prepare("UPDATE enrollments SET status = 'active' WHERE id = :id");
            $stmt->execute(['id' => $enrollment_id]);
            
            // Send approval email
            $mail->Subject = 'Course Enrollment Approved';
            $mail->Body    = "Dear " . $user['username'] . ",\n\nYour enrollment for the course '" . $user['category_name'] . "' has been approved.\n\nBest Regards,\nAdmin Team";
            $mail->send();
            
            $message = "Enrollment approved successfully.";
        } elseif ($action === 'reject') {
            // Update the enrollment status
            $stmt = $pdo->prepare("UPDATE enrollments SET status = 'rejected' WHERE id = :id");
            $stmt->execute(['id' => $enrollment_id]);

            // Send rejection email
            $mail->Subject = 'Course Enrollment Rejected';
            $mail->Body    = "Dear " . $user['username'] . ",\n\nWe regret to inform you that your enrollment for the course '" . $user['category_name'] . "' has been rejected.\n\nBest Regards,\nAdmin Team";
            $mail->send();
            
            $message = "Enrollment rejected successfully.";
        } elseif ($action === 'revoke') {
            // Revoke access (set status to 'revoked')
            $stmt = $pdo->prepare("UPDATE enrollments SET status = 'revoked' WHERE id = :id");
            $stmt->execute(['id' => $enrollment_id]);

            // Send revocation email
            $mail->Subject = 'Course Access Revoked';
            $mail->Body    = "Dear " . $user['username'] . ",\n\nYour access to the course '" . $user['category_name'] . "' has been revoked.\n\nBest Regards,\nAdmin Team";
            $mail->send();

            $message = "Access revoked successfully.";
        }
    } catch (Exception $e) {
        $message = "Error in sending email: {$mail->ErrorInfo}";
    }
}

// Pagination calculation
$totalStmt = $pdo->query("SELECT COUNT(*) FROM enrollments");
$totalEnrollments = $totalStmt->fetchColumn();
$totalPages = ceil($totalEnrollments / $limit);

// Count total pending enrollments for pagination
$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE status = 'pending'");
$totalStmt->execute();
$totalPending = $totalStmt->fetchColumn();

// Count total approved enrollments
$approvedStmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE status = 'active'");
$approvedStmt->execute();
$totalApproved = $approvedStmt->fetchColumn();

// Count today's enrollments
$todayStmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE DATE(created_at) = CURDATE()");
$todayStmt->execute();
$totalToday = $todayStmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Enrollment Statuses</title>
     <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        form {
     background-color: #fff; 
     padding: 0; 
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="logo">
                <img src="../logo.png" alt="Logo">
                <h2>Admin Panel</h2>
            </div>
            <nav>
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="videos.php"><i class="fas fa-video"></i> Videos</a></li>
                    <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                    <li><a href="categories.php"><i class="fas fa-tags"></i> Categories</a></li>
                    <li><a href="admin_approvals.php"><i class="fas fa-cog"></i> Course Approvals</a></li>
                    <li><a href="admin_statuses.php" class="active"><i class="fas fa-cog"></i> Enrollment Statuses</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </div>
                <div class="main-content">
    <div class="container mt-4">
        <h2>All Enrollment Statuses </h2>

        <?php if (!empty($message)): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
<div class="row mb-3">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-body">
                <h5 class="card-title">Total Requests Today</h5>
                <p class="card-text"><?php echo $totalToday; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-warning mb-3">
            <div class="card-body">
                <h5 class="card-title">Total Pending</h5>
                <p class="card-text"><?php echo $totalPending; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-body">
                <h5 class="card-title">Total Approved</h5>
                <p class="card-text"><?php echo $totalApproved; ?></p>
            </div>
        </div>
    </div>
</div>

        <div class="row mb-3">
            
            <div class="col-md-6 text-end">
                <form method="GET" class="d-flex">
                    <input type="text" name="search" class="form-control me-2" placeholder="Search by user or category" value="<?php echo htmlspecialchars($search); ?>">
                    <select name="limit" class="form-select me-2" onchange="this.form.submit()">
                        <option value="10" <?php echo $limit === 10 ? 'selected' : ''; ?>>10</option>
                        <option value="20" <?php echo $limit === 20 ? 'selected' : ''; ?>>20</option>
                        <option value="50" <?php echo $limit === 50 ? 'selected' : ''; ?>>50</option>
                        <option value="100" <?php echo $limit === 100 ? 'selected' : ''; ?>>100</option>
                    </select>
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>

        <form method="GET" class="mb-3">
            <select name="category" class="form-select" onchange="this.form.submit()">
                <option value="">All Categories</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo $categoryFilter == $category['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($category['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </form>
                <table class="table table-bordered mt-3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Course</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($enrollments): ?>
                                  <?php
        // Initialize serial number counter
        $serialNumber = ($page - 1) * $limit + 1;
        ?>
                            <?php foreach ($enrollments as $enrollment): ?>
                                <tr>
                                    <td><?php echo $serialNumber++; ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['username']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['category_name']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['status']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['created_at']); ?></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="enrollment_id" value="<?php echo $enrollment['id']; ?>">
                                            <?php if ($enrollment['status'] == 'pending'): ?>
                                                <button type="submit" name="action" value="approve" class="btn btn-success">Approve</button>
                                                <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                                            <?php elseif ($enrollment['status'] == 'active'): ?>
                                                <button type="submit" name="action" value="revoke" class="btn btn-warning">Revoke Access</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No enrollments found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&limit=<?php echo $limit; ?>&search=<?php echo $search; ?>&category=<?php echo $categoryFilter; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
