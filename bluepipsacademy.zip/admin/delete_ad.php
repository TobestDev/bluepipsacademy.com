<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $stmt = $pdo->prepare("DELETE FROM advertisements WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: ads_settings.php');
    exit();
}
