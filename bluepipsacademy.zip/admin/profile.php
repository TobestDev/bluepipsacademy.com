<?php
session_start();
require_once '../Settings/config.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: logout.php");
    exit;
}

$admin_id = $_SESSION['admin_id'];

$stmt = $pdo->prepare("SELECT username, created_at FROM admin WHERE id = :id");
$stmt->execute(['id' => $admin_id]);
$admin = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="../acesst/css/style.css">
</head>
<body>
    <?php include '../Settings/header.php'; ?>
    <div class="container">
        <h1>Admin Profile</h1>
        <p>Username: <?php echo $admin['username']; ?></p>
        <p>Admin since: <?php echo $admin['created_at']; ?></p>
        <a href="user_management.php">User Management</a>
        <a href="category_management.php">Category Management</a>
        <a href="video_management.php">Video Management</a>
        <a href="../logout.php">Logout</a>
    </div>
    <?php include '../Settings/footer.php'; ?>
    <script src="../acesst/js/script.js"></script>
</body>
</html>
