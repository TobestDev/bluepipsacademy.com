 <nav>
            <ul>
                 <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="videos.php"><i class="fas fa-video"></i> Videos</a></li>
                    <li><a href="upload_testimony.php"><i class="fas fa-video"></i> Testimonies</a></li>
                    <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                    <li><a href="categories.php"><i class="fas fa-tags"></i> Categories</a></li>
                    <li><a href="admin_webinar.php"><i class="fas fa-tags"></i> Webinar</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                    <li><a href="ads_settings.php"><i class="fas fa-cog"></i> Ads_setting</a></li>
                    <li><a href="admin_approvals.php"><i class="fas fa-cog"></i> Course Approvals</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>