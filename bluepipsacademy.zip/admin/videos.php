<?php
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Handle video deletion
if (isset($_GET['delete'])) {
    $video_id = intval($_GET['delete']);

    // Fetch the video details to delete the file from the server
    $stmt = $pdo->prepare("SELECT file_path FROM videos WHERE id = ?");
    $stmt->execute([$video_id]);
    $video = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($video) {
        // Delete the file from the server
        $file_path = '../uploads/' . $video['file_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // Delete the video from the database
        $stmt = $pdo->prepare("DELETE FROM videos WHERE id = ?");
        $stmt->execute([$video_id]);

        if ($stmt->rowCount()) {
            echo "<script>alert('Video deleted successfully');</script>";
        } else {
            echo "<script>alert('Failed to delete video from database');</script>";
        }
    } else {
        echo "<script>alert('Video not found');</script>";
    }

    // Redirect to avoid the delete query being triggered on page reload
    header('Location: videos.php');
    exit();
}

// Fetch all videos
$stmt = $pdo->prepare("SELECT videos.id, videos.title, videos.original_name, videos.file_path, categories.name as category_name FROM videos JOIN categories ON videos.category_id = categories.id ORDER BY videos.created_at DESC");
$stmt->execute();
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all categories for the form
$stmt = $pdo->prepare("SELECT * FROM categories ORDER BY name ASC");
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Videos</title>
    <style>
        /* Styles for the progress bar */
        .progress {
            width: 100%;
            background-color: #f3f3f3;
        }
        .progress-bar {
            width: 0;
            height: 20px;
            background-color: #4caf50;
            text-align: center;
            line-height: 20px;
            color: white;
        }
    </style>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
       <?php include 'css/header.php'; ?>
    </div>
    <div class="main-content">
        <h1>Manage Videos</h1>
        
        <!-- Add Video Form -->
        <form id="upload-form" class="form">
            <h2>Add New Videos</h2>
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" required>
            <label for="files">Select Videos:</label>
            <input type="file" name="files[]" id="files" multiple accept="video/*" required>
            <label for="category_id">Category:</label>
            <select name="category_id" id="category_id" required>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="button" id="upload-button">Add Videos</button>
        </form>

        <!-- Progress Bar -->
        <div class="progress">
            <div class="progress-bar" id="progress-bar">0%</div>
        </div>

        <!-- Videos Table -->
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Original Name</th>
                    <th>File Path</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($videos as $video): ?>
                    <tr>
                        <td><?= htmlspecialchars($video['title']) ?></td>
                        <td><?= htmlspecialchars($video['original_name']) ?></td>
                        <td><a href="../uploads/<?= htmlspecialchars($video['file_path']) ?>" target="_blank"><?= htmlspecialchars($video['file_path']) ?></a></td>
                        <td><?= htmlspecialchars($video['category_name']) ?></td>
                        <td>
                            <a href="edit_video.php?id=<?= $video['id'] ?>">Edit</a> | 
                            <a href="videos.php?delete=<?= $video['id'] ?>" onclick="return confirm('Are you sure you want to delete this video?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.getElementById('upload-button').addEventListener('click', function() {
        const form = document.getElementById('upload-form');
        const formData = new FormData(form);
        const files = document.getElementById('files').files;
        const progressBar = document.getElementById('progress-bar');
        const totalFiles = files.length;

        if (totalFiles === 0) {
            alert('Please select files to upload.');
            return;
        }

        let uploadedFiles = 0;

        function uploadNextFile(index) {
            if (index >= totalFiles) {
                progressBar.style.width = '100%';
                progressBar.innerHTML = 'Upload Complete';
                setTimeout(() => location.reload(), 1000);
                return;
            }

            const fileData = new FormData();
            fileData.append('file', files[index]);
            fileData.append('title', formData.get('title'));
            fileData.append('category_id', formData.get('category_id'));

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload_video.php', true);

            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    progressBar.style.width = percentComplete + '%';
                    progressBar.innerHTML = Math.round(percentComplete) + '%';
                }
            });

            xhr.onload = function() {
                if (xhr.status === 200) {
                    uploadedFiles++;
                    const overallProgress = (uploadedFiles / totalFiles) * 100;
                    progressBar.style.width = overallProgress + '%';
                    progressBar.innerHTML = Math.round(overallProgress) + '%';
                    uploadNextFile(index + 1);
                } else {
                    alert('Error uploading file.');
                }
            };

            xhr.send(fileData);
        }

        uploadNextFile(0);
    });
</script>
</body>
</html>
