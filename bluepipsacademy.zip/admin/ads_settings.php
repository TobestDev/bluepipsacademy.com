<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Code for handling form submission to add a new advertisement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save uploaded image to server
    $targetDir = "uploads/ads/";
    $imageFileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $imageFileName;
    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath);

    // Insert ad into database
    $stmt = $pdo->prepare("INSERT INTO advertisements (image_url, redirect_url, is_active) VALUES (?, ?, ?)");
    $stmt->execute([
        "uploads/ads/" . $imageFileName,
        $_POST['redirect_url'] ?? null,
        isset($_POST['is_active']) ? 1 : 0
    ]);

    header("Location: ads_settings.php"); // Redirect to ad management page
    exit();
}

// Fetch all advertisements from the database
$stmt = $pdo->prepare("SELECT * FROM advertisements");
$stmt->execute();
$ads = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Advertisements</title>
    <style>
        .ad-table {
            width: 100%;
            border-collapse: collapse;
        }
        .ad-table th, .ad-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .ad-table img {
            width: 100px;
            height: auto;
            border-radius: 5px;
        }
        .btn {
            padding: 5px 10px;
            margin: 2px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .btn-active { background-color: #4caf50; color: white; }
        .btn-deactivate { background-color: #f44336; color: white; }
        .btn-delete { background-color: #e74c3c; color: white; }
    </style>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
        <?php include 'css/header.php'; ?>
    </div>
    <div class="main-content">
        <h1>Manage Advertisements</h1>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="image" required>
            <input type="url" name="redirect_url" placeholder="Redirect URL (optional)">
            <label>
                <input type="checkbox" name="is_active" value="1" checked> Active
            </label>
            <button type="submit">Add Advertisement</button>
        </form>

        <h2>Current Advertisements</h2>
        <table class="ad-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Redirect URL</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ads as $ad): ?>
                    <tr>
                        <td><img src="<?php echo htmlspecialchars($ad['image_url']); ?>" alt="Ad Image"></td>
                        <td><a href="<?php echo htmlspecialchars($ad['redirect_url']); ?>" target="_blank">Link</a></td>
                        <td><?php echo $ad['is_active'] ? 'Active' : 'Inactive'; ?></td>
                        <td>
                            <?php if ($ad['is_active']): ?>
                                <a href="toggle_ad_status.php?id=<?php echo $ad['id']; ?>&action=deactivate" class="btn btn-deactivate">Deactivate</a>
                            <?php else: ?>
                                <a href="toggle_ad_status.php?id=<?php echo $ad['id']; ?>&action=activate" class="btn btn-active">Activate</a>
                            <?php endif; ?>
                            <a href="delete_ad.php?id=<?php echo $ad['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this ad?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script></script>
</body>
</html>
