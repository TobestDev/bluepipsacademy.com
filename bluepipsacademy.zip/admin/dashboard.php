<?php
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Fetch admin details
$stmt = $pdo->prepare('SELECT * FROM admin WHERE id = ?');
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch some stats or data for the dashboard
$total_users_stmt = $pdo->query('SELECT COUNT(*) FROM users');
$total_users = $total_users_stmt->fetchColumn();

$total_videos_stmt = $pdo->query('SELECT COUNT(*) FROM videos');
$total_videos = $total_videos_stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
<style>
  
</style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="logo">
                <img src="../logo.png" alt="Logo">
                <h2>Admin Panel</h2>
            </div>
            <?php include 'css/header.php'; ?>
        </div>
        <div class="main-content">
            <h1>Welcome, <?php echo htmlspecialchars($admin['username']); ?></h1>
            <div class="stats">
                <div class="stat">
                    <h3>Total Users</h3>
                    <p><?php echo $total_users; ?></p>
                </div>
                <div class="stat">
                    <h3>Total Videos</h3>
                    <p><?php echo $total_videos; ?></p>
                </div>
            </div>
        </div>
    </div>
    <script src="../script.js"></script>
</body>
</html>
