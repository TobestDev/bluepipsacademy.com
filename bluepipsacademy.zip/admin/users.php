<?php
session_start();
require_once '../Settings/config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// required files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Fetch all users
$stmt = $pdo->prepare("SELECT * FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle adding a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->execute([$username, $password]);

    header('Location: users.php');
    exit;
}

// Handle deleting a user
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: users.php');
    exit;
}

// Handle approving or disabling a user
if (isset($_GET['toggle_approval'])) {
    $id = $_GET['toggle_approval'];
    $is_approved = $_GET['current_status'] == 1 ? 0 : 1;

    $stmt = $pdo->prepare("UPDATE users SET is_approved = ? WHERE id = ?");
    $stmt->execute([$is_approved, $id]);

    // Fetch user email
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Send email notification
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'lorem.ipsum.sample.email@gmail.com';
            $mail->Password   = 'tetmxtzkfgkwgpsc';
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;

            // Recipients
            $mail->setFrom('apstfortunate@gmail.com', 'Apostle Fortunate');
            $mail->addAddress($user['email']);
            $mail->addReplyTo('apstfortunate@gmail.com', 'Apostle Fortunate');

            // Content
            $mail->isHTML(true);

            if ($is_approved) {
                $mail->Subject = 'Account Approval';
                $mail->Body = '
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    background-color: #f9f9f9;
                }
                h1 {
                    color: #4CAF50;
                }
                p {
                    margin-bottom: 15px;
                }
                .important {
                    font-weight: bold;
                    color: #FF5722;
                }
                .note {
                    font-style: italic;
                }
                .social {
                    margin-top: 20px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Payment Confirmed - Access Granted!</h1>
                <p>Dear User,</p>
                <p>Your payment has been confirmed, and your access has been granted!</p>
                <p>Please proceed to our site: <a href="https://courses.apostlefortunate.com/">Avalanche Wealth</a>.</p>
                <p>Locate the course titled <strong>BLUEPIPS TRADING ACADEMY</strong> and study it extensively. We recommend studying the course at least three times with intense practice.</p>
                <p class="important">Note all questions and let us know once you have completed all the studying and practicing.</p>
                <p>Please remember that diligent study and practice are crucial. This will help us schedule live sessions with you.</p>
                <p class="important">There is no refund of the registration/subscription fee, regardless of circumstances, if you do not follow the instructions precisely.</p>
                <p class="note">Note: We no longer provide signals. If you see references to signals in the course, that was previously. We no longer offer them.</p>
                <p>Best wishes,</p>
                <p><strong>APOSTLEFORTUNATE 💖</strong></p>
                <div class="social">
                    <p>Follow me on all social media: <strong>@APOSTLEFORTUNATE</strong></p>
                </div>
            </div>
        </body>
        </html>';
            } else {
                $mail->Subject = 'Account Disabled';
                $mail->Body    = 'Your account has been disabled. Please contact the admin in the WhatsApp group for further instructions.';
            }

            $mail->send();
        } catch (Exception $e) {
            error_log("Mailer Error: {$mail->ErrorInfo}");
        }
    }

    header('Location: users.php');
    exit;
}

// Handle editing a user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
    $stmt->execute([$username, $password, $id]);

    header('Location: users.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Users</title>
    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Link copied to clipboard!');
            }, function(err) {
                alert('Failed to copy link: ' + err);
            });
        }
    </script>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
      <?php include 'css/header.php'; ?>
    </div>
    <div class="main-content">
        <h1>Manage Users</h1>
        
        <!-- Add User Form -->
        <form method="POST" class="form">
            <h2>Add New User</h2>
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <button type="submit" name="add_user">Add User</button>
        </form>

        <!-- Users Table -->
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Created At</th>
                    <th>Approval Status</th>
                    <th>Copy Link</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['created_at']) ?></td>
                        <td><?= $user['is_approved'] ? 'Approved' : 'Disabled' ?></td>
                        <td>
                            <button onclick="copyToClipboard('https://yourwebsite.com/invite.php?user_id=<?= $user['id'] ?>')">Copy Link</button>
                        </td>
                        <td>
                            <a href="edit_user.php?id=<?= $user['id'] ?>">Edit</a> | 
                            <a href="users.php?delete=<?= $user['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a> | 
                            <a href="users.php?toggle_approval=<?= $user['id'] ?>&current_status=<?= $user['is_approved'] ?>">
                                <?= $user['is_approved'] ? 'Disable' : 'Approve' ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
