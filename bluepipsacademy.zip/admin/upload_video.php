<?php
require_once '../Settings/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $category_id = $_POST['category_id'];
    $file = $_FILES['file'];

    if ($file['error'] === UPLOAD_ERR_OK) {
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $new_file_name = uniqid('', true) . '.' . $file_ext;
        $upload_path = '../uploads/' . $new_file_name;

        if (move_uploaded_file($file_tmp, $upload_path)) {
            $stmt = $pdo->prepare("INSERT INTO videos (title, original_name, file_path, category_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$title, $file_name, $new_file_name, $category_id]);
            echo 'File uploaded successfully';
        } else {
            http_response_code(500);
            echo 'Failed to move uploaded file.';
        }
    } else {
        http_response_code(400);
        echo 'Error uploading file.';
    }
}
?>
