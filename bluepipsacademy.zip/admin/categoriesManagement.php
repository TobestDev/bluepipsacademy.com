<?php
session_start();
require_once '../Settings/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: logout.php');
    exit();
}

// Fetch all categories
$stmt = $pdo->prepare("SELECT * FROM categories ORDER BY created_at DESC");
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle adding a new category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $course_outline = $_POST['course_outline'] ?? null; // Optional
    $advantages = $_POST['advantages'] ?? null; // Optional
    $certification = $_POST['certification'] ?? null; // Optional
    $overview_videos = $_FILES['overview_videos'] ?? null; // Optional

    // Handle image upload
    if (!empty($_FILES['image']['name'])) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $upload_dir = 'category/';
        $image_path = $upload_dir . basename($image_name);
        move_uploaded_file($image_tmp, $image_path);
    } else {
        $image_path = null; // No image uploaded
    }

    // Handle overview video uploads (max 2)
    $video_paths = [];
    if ($overview_videos && count($overview_videos['name']) > 0) {
        for ($i = 0; $i < count($overview_videos['name']); $i++) {
            if ($overview_videos['size'][$i] > 0 && $i < 2) { // Limit to 2 videos
                $video_name = $overview_videos['name'][$i];
                $video_tmp = $overview_videos['tmp_name'][$i];
                $video_path = 'videos/' . basename($video_name);
                move_uploaded_file($video_tmp, $video_path);
                $video_paths[] = $video_path;
            }
        }
    }

    // Prepare video paths for database
    $video_paths_str = implode(',', $video_paths);

    $stmt = $pdo->prepare("INSERT INTO categories (name, description, image, course_outline, advantages, certification, overview_videos) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $image_path, $course_outline, $advantages, $certification, $video_paths_str]);

    header('Location: categories.php');
    exit;
}

// Handle deleting a category
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Delete the category
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: categories.php');
    exit;
}

// Handle editing a category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_category'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $course_outline = $_POST['course_outline'] ?? null; // Optional
    $advantages = $_POST['advantages'] ?? null; // Optional
    $certification = $_POST['certification'] ?? null; // Optional

    // Check if a new image is uploaded
    if (!empty($_FILES['image']['name'])) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $upload_dir = 'category/';
        $image_path = $upload_dir . basename($image_name);
        move_uploaded_file($image_tmp, $image_path);
        
        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, image = ?, course_outline = ?, advantages = ?, certification = ? WHERE id = ?");
        $stmt->execute([$name, $description, $image_path, $course_outline, $advantages, $certification, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ?, course_outline = ?, advantages = ?, certification = ? WHERE id = ?");
        $stmt->execute([$name, $description, $course_outline, $advantages, $certification, $id]);
    }

    header('Location: categories.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin - Manage Categories</title>
    <script>
        function copyToClipboard(text) {
            const tempInput = document.createElement('input');
            tempInput.value = text;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            alert('Link copied to clipboard!');
        }
    </script>
</head>
<body>
<div class="dashboard">
    <div class="sidebar">
        <div class="logo">
            <h2>Admin Panel</h2>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="videos.php"><i class="fas fa-video"></i> Videos</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="categories.php"><i class="fas fa-tags"></i> Categories</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="admin_approvals.php"><i class="fas fa-cog"></i> Course Approvals</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <h1>Manage Categories</h1>
        
        <!-- Add Category Form -->
        <form method="POST" enctype="multipart/form-data" class="form">
            <h2>Add New Category</h2>
            <label for="name">Category Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="description">Category Description:</label>
            <textarea name="description" id="description" required></textarea>

            <label for="course_outline">Course Outline:</label>
            <textarea name="course_outline" id="course_outline" placeholder="Optional"></textarea>

            <label for="advantages">Advantages of the Course:</label>
            <textarea name="advantages" id="advantages" placeholder="Optional"></textarea>

            <label for="certification">Certification:</label>
            <textarea name="certification" id="certification" placeholder="Optional"></textarea>

            <label for="image">Category Image:</label>
            <input type="file" name="image" id="image" accept="image/*" required>

            <label for="overview_videos">Overview Videos (max 2):</label>
            <input type="file" name="overview_videos[]" id="overview_videos" accept="video/*" multiple>

            <button type="submit" name="add_category">Add Category</button>
        </form>

        <!-- Categories Table -->
        <table>
            <thead>
                <tr>
                    <th>Category Name</th>
                    <th>Image</th>
                    <th>Created At</th>
                    <th>Signup Link</th>
                    <th>Share Link</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= htmlspecialchars($category['name']) ?></td>
                        
                        <td>
                            <?php if ($category['image']): ?>
                                <img src="<?= $category['image'] ?>" alt="<?= htmlspecialchars($category['name']) ?>" style="width: 100px; height: auto;">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($category['created_at']) ?></td>
                        <td><a href="../user/signup.php?category_id=<?= $category['id'] ?>">Signup for this Category</a></td>
                        <td><button onclick="copyToClipboard('courses.apostlefortunate.com/user/signup.php?category_id=<?= $category['id'] ?>')">Copy Link</button></td>
                        <td>
                            <a href="edit_category.php?id=<?= $category['id'] ?>">Edit</a> | 
                            <a href="categories.php?delete=<?= $category['id'] ?>" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
