<header>
    <nav>
        <ul>
            <li><a href="/User/index.php">Home</a></li>
            <li><a href="/User/profile.php">Profile</a></li>
            <li><a href="/User/video.php">Videos</a></li>
            <li><a href="../logout.php">Logout</a></li>
        </ul>
    </nav>
</header>
