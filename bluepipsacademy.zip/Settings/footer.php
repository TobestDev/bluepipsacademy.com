<footer>
    <p>&copy; TobestDev 2024 Your Website. All rights reserved.</p>
</footer>
